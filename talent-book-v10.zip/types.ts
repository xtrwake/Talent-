
export type TypeUtilisateur = 'candidat' | 'entreprise' | 'admin';
export type StatutCompte = 'actif' | 'suspendu' | 'supprime';
export type Genre = 'Homme' | 'Femme' | 'Autre' | 'Préfère ne pas répondre';

export interface FicheMetier {
  id: string;
  secteur: string;
  metier: string;
  code_rome: string;
  competences: string[];
  soft_skills?: string[];
  passerelles?: string[];
  tension: boolean;
  actif: boolean;
  date_creation: string;
}

export interface TalentCard {
  id: string;
  titre: string;
  secteur?: string;
  metier?: string;
  competences: string[];
  softSkills?: string[];
  logiciels?: string[];
  experience?: string;
  disponibilite?: string;
  type_contrat?: string;
  niveau?: 'Débutant' | 'Confirmé' | 'Expert';
  ville?: string;
  code_postal?: string;
  rayon_mobilite?: string;
  cv_ids?: string[];
}

export interface Utilisateur {
  id: string;
  email: string;
  identifiant: string;
  password?: string;
  type_utilisateur: TypeUtilisateur;
  statut_compte: StatutCompte;
  date_creation: string;
  auth_provider: 'email' | 'google' | 'facebook' | 'linkedin';
  social_id?: string | null;
}

export interface ProfilCandidat {
  id: string;
  utilisateur_id: string;
  identifiant: string;
  nom: string;
  prenom: string;
  date_naissance: string;
  genre: Genre;
  telephone: string;
  ville_principale?: string;
  code_postal?: string;
  photo_url?: string;
  cv_url?: string;
  cvList?: { id: string; nom: string; base64: string; date: string }[];
  bio?: string;
  titre?: string;
  fiches: FicheCandidat[];
  profileViews: number;
  companyMatches: number;
  activeRecommendations: number;
  isProfileVisible: boolean;
  talentCards: TalentCard[];
}

export interface FicheCandidat {
  id: string;
  profil_candidat_id: string;
  secteur: string;
  metier: string;
  niveau?: 'Débutant' | 'Confirmé' | 'Expert';
  competences_techniques: string[];
  soft_skills: string[];
  passerelles?: string[];
  enseigne_preferee: string;
  disponibilite: 'immediate' | '1 mois' | '> 1 mois';
  type_contrat: 'CDI' | 'CDD' | 'Alternance';
  ville: string;
  code_postal: string;
  rayon_mobilite: number;
  logiciels: string[];
  est_actif: boolean;
  date_creation: string;
}

export interface ProfilEntreprise {
  id: string;
  utilisateur_id: string;
  nom_entreprise: string;
  identifiant: string;
  enseigne: string;
  secteur_activite: string;
  ville: string;
  code_postal: string;
  contact_nom: string;
  contact_poste: string;
  credits: number;
  description?: string;
  logo_url?: string;
  est_verifie: boolean;
  offres?: OffreEmploi[];
}

export interface OffreEmploi {
  id: string;
  profil_entreprise_id: string;
  titre_poste: string;
  type_contrat: string;
  ville: string;
  description: string;
  statut: 'active' | 'inactive';
  date_creation: string;
}
