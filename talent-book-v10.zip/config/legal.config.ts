// ─────────────────────────────────────────────────────────────
// TALENTBOOK — Configuration légale centralisée
// Groupe XtrLabs · MAESTRO v1.0
// Mettez à jour ce seul fichier pour propager sur toutes les pages légales.
// ─────────────────────────────────────────────────────────────

export interface LegalConfig {
  company: {
    name: string;
    group: string;
    legal_form: string;
    siret: string;
    rcs: string;
    rcs_city: string;
    address: string;
    city: string;
    zip: string;
    vat_number: string;
    legal_rep_name: string;
    legal_rep_title: string;
    email_rgpd: string;
    email_contact: string;
    host_name: string;
    host_address: string;
    court_city: string;
    last_updated: string;
    cgu_version: string;
    cgv_version: string;
  };
}

export const LEGAL_CONFIG: LegalConfig = {
  company: {
    name: 'TalentBook',
    group: 'XtrLabs',
    legal_form: 'SAS',
    siret: '',           // À COMPLÉTER
    rcs: '',             // À COMPLÉTER
    rcs_city: '',        // À COMPLÉTER
    address: '',         // À COMPLÉTER
    city: '',            // À COMPLÉTER
    zip: '',             // À COMPLÉTER
    vat_number: '',      // À COMPLÉTER
    legal_rep_name: '',  // À COMPLÉTER
    legal_rep_title: '', // À COMPLÉTER
    email_rgpd: 'rgpd@talentbook.fr',
    email_contact: 'contact@talentbook.fr',
    host_name: '',       // À COMPLÉTER
    host_address: '',    // À COMPLÉTER
    court_city: '',      // À COMPLÉTER
    last_updated: '2024-01-01',
    cgu_version: '1.0',
    cgv_version: '1.0',
  }
};

// Helper : affiche la valeur ou un badge [À COMPLÉTER] si vide
export function legalField(value: string, fallback = ''): string {
  if (value && value.trim() !== '') return value;
  return fallback || '[À COMPLÉTER]';
}

// Helper : vérifie si on est en dev (pour afficher les badges visuels)
export const IS_DEV = import.meta.env.DEV;
