
import React, { useState, useEffect, useRef } from 'react';
import { Logo, BrandText } from './components/Logo';
import { CGUPage, CGVPage, MentionsLegalesPage, ConfidentialitePage, ContratB2BPage, ContratB2BModal, CookieBanner, LegalFooter } from './components/Legal';
import { 
  Utilisateur, 
  ProfilCandidat, 
  ProfilEntreprise, 
  TypeUtilisateur, 
  FicheMetier, 
  FicheCandidat,
  Genre,
  StatutCompte,
  TalentCard
} from './types';

type ViewState = 'landing' | 'login' | 'signup' | 'profile_setup' | 'candidate_dashboard' | 'company_dashboard' | 'admin_dashboard' | 'metiers_explorer' | 'talent_card' | 'mini_scope_admin' | 'legal_cgu' | 'legal_cgv' | 'legal_mentions' | 'legal_confidentialite' | 'legal_contrat_b2b';

// --- DATABASE ENGINE (Simulated Firestore/Auth Layer) ---
// ⚠️ ATTENTION : Les mots de passe sont stockés en clair uniquement pour la démo.
// En production, utiliser bcrypt ou Argon2 + une vraie base de données sécurisée.
const DB_KEY = 'talentbook_v6_db';

const getInitialDB = () => ({
  users: [
    { id: 'admin-id', email: 'admin@talentbook.fr', identifiant: 'admin', password: 'Prinpan2&', type_utilisateur: 'admin' as TypeUtilisateur, statut_compte: 'actif' as StatutCompte, date_creation: new Date().toISOString(), auth_provider: 'email', social_id: null },
    { id: 'candidat1-id', email: 'candidat1@talentbook.fr', identifiant: 'candidat1', password: 'Test123&', type_utilisateur: 'candidat' as TypeUtilisateur, statut_compte: 'actif' as StatutCompte, date_creation: new Date().toISOString(), auth_provider: 'email', social_id: null },
    { id: 'entreprise1-id', email: 'entreprise1@talentbook.fr', identifiant: 'entreprise1', password: 'Test123&', type_utilisateur: 'entreprise' as TypeUtilisateur, statut_compte: 'actif' as StatutCompte, date_creation: new Date().toISOString(), auth_provider: 'email', social_id: null },
  ],
  profils_candidats: [
    { 
      id: 'p1', 
      utilisateur_id: 'candidat1-id', 
      identifiant: 'candidat1', 
      nom: 'Candidat', 
      prenom: 'Test', 
      date_naissance: '1990-01-01', 
      genre: 'Homme' as Genre, 
      telephone: '0600000001', 
      photo_url: '', 
      fiches: [],
      profileViews: 124,
      companyMatches: 3,
      activeRecommendations: 2,
      isProfileVisible: true,
      talentCards: [
        { id: 'tc1', titre: 'Développeur React Expert', competences: ['React', 'TypeScript'], logiciels: ['VS Code'], experience: '3 ans', disponibilite: 'Immédiate' }
      ],
      bio: "Passionné par le développement d'interfaces modernes."
    }
  ],
  profils_entreprises: [
    { id: 'e1', utilisateur_id: 'entreprise1-id', identifiant: 'entreprise1', nom_entreprise: 'Entreprise Test', enseigne: 'Test Corp', secteur_activite: 'Tech', ville: 'Paris', code_postal: '75000', contact_nom: 'Recruteur', contact_poste: 'HR', credits: 10, est_verifie: true, logo_url: 'https://images.unsplash.com/photo-1549923746-c502d488b3ea?w=100&h=100&fit=crop' }
  ],
  miniscope_secteurs: [
    { id: 's1', nom: "Santé / Social", actif: true },
    { id: 's2', nom: "Tech", actif: true },
    { id: 's3', nom: "Commerce", actif: true },
    { id: 's4', nom: "BTP", actif: true },
    { id: 's5', nom: "Hôtellerie / Restauration", actif: true },
    { id: 's6', nom: "Commerce / Grande Distribution", actif: true }
  ],
  miniscope_metiers: [
    { 
      id: 'm1', 
      secteur_id: 's1', 
      nom_metier: "Aide-soignant / Aide-soignante", 
      competences_techniques: ["Soins d'hygiène", "Aide à la mobilité", "Prise de constantes", "Préparation des repas"],
      soft_skills: ["Empathie", "Patience", "Résistance physique", "Travail en équipe"],
      passerelles: []
    },
    { 
      id: 'm2', 
      secteur_id: 's2', 
      nom_metier: "Développeur Front-end", 
      competences_techniques: ["React", "TypeScript", "Tailwind CSS", "Vue.js", "HTML/CSS"],
      soft_skills: ["Résolution de problèmes", "Autonomie", "Curiosité", "Communication"],
      passerelles: []
    },
    { 
      id: 'm3', 
      secteur_id: 's3', 
      nom_metier: "Vendeur / Vendeuse", 
      competences_techniques: ["Encaissement", "Mise en rayon", "Gestion des stocks", "Conseil client"],
      soft_skills: ["Sens du relationnel", "Sourire", "Persuasion", "Dynamisme"],
      passerelles: []
    },
    { 
      id: 'm4', 
      secteur_id: 's4', 
      nom_metier: "Électricien / Électricienne", 
      competences_techniques: ["Lecture de plans", "Pose de câblage", "Installation d'appareillage", "Maintenance"],
      soft_skills: ["Rigueur", "Prudence", "Esprit d'analyse", "Habileté manuelle"],
      passerelles: []
    },
    // GMS SECTOR
    {
      id: 'gms1',
      secteur_id: 's6',
      nom_metier: "Employé libre-service",
      competences_techniques: ["mise en rayon", "rotation des produits", "gestion des stocks", "balisage prix", "contrôle DLC", "inventaire", "utilisation transpalette"],
      soft_skills: ["rigueur", "organisation", "autonomie", "travail en équipe", "relation client", "sens du commerce"],
      passerelles: ["Préparateur de commandes Drive", "Adjoint chef de rayon"]
    },
    {
      id: 'gms2',
      secteur_id: 's6',
      nom_metier: "Hôte de caisse",
      competences_techniques: ["encaissement", "gestion des moyens de paiement", "accueil client", "clôture de caisse", "gestion des litiges", "fidélisation client"],
      soft_skills: ["rigueur", "organisation", "relation client", "gestion du stress", "communication", "sens du commerce"],
      passerelles: ["Employé libre-service", "Vendeur conseil"]
    },
    {
      id: 'gms3',
      secteur_id: 's6',
      nom_metier: "Préparateur de commandes Drive",
      competences_techniques: ["préparation de commandes", "scan produits", "contrôle qualité", "gestion des stocks", "respect des délais", "utilisation chariot"],
      soft_skills: ["rigueur", "organisation", "autonomie", "travail en équipe", "gestion du stress"],
      passerelles: []
    },
    {
      id: 'gms4',
      secteur_id: 's6',
      nom_metier: "Adjoint chef de rayon",
      competences_techniques: ["gestion de rayon", "management d’équipe", "analyse chiffre d’affaires", "gestion commandes", "implantation promotionnelle", "gestion inventaire"],
      soft_skills: ["rigueur", "organisation", "leadership", "prise de décision", "communication", "sens du commerce"],
      passerelles: ["Chef de rayon"]
    },
    {
      id: 'gms5',
      secteur_id: 's6',
      nom_metier: "Chef de rayon",
      competences_techniques: ["pilotage chiffre d’affaires", "gestion marge", "management équipe", "négociation fournisseurs", "gestion des stocks", "reporting performance"],
      soft_skills: ["rigueur", "organisation", "leadership", "prise de décision", "communication", "sens du commerce"],
      passerelles: ["Responsable secteur"]
    },
    {
      id: 'gms6',
      secteur_id: 's6',
      nom_metier: "Responsable secteur",
      competences_techniques: ["pilotage performance commerciale", "management multi-équipes", "stratégie commerciale", "gestion budget", "analyse indicateurs"],
      soft_skills: ["leadership", "prise de décision", "communication", "sens du commerce", "organisation", "rigueur"],
      passerelles: []
    }
  ],
  metiers: [
    { id: 'm1', secteur: "Santé / Social", metier: "Aide-soignant / Aide-soignante", code_rome: "J1502", competences: ["Soins d'hygiène", "Aide à la mobility", "Relationnel"], tension: true, actif: true, date_creation: new Date().toISOString() },
    { id: 'm2', secteur: "Tech", metier: "Développeur Front-end", code_rome: "M1805", competences: ["React", "TypeScript", "Tailwind"], tension: true, actif: true, date_creation: new Date().toISOString() },
  ]
});

const getDB = () => {
  const stored = localStorage.getItem(DB_KEY);
  if (stored) {
    const db = JSON.parse(stored);
    const hasAdmin = db.users.some((u: any) => u.identifiant === 'admin');
    if (!hasAdmin) {
      const initial = getInitialDB();
      db.users.push(...initial.users.filter(u => !db.users.some((ex: any) => ex.identifiant === u.identifiant)));
      localStorage.setItem(DB_KEY, JSON.stringify(db));
    }
    return db;
  }
  const initial = getInitialDB();
  localStorage.setItem(DB_KEY, JSON.stringify(initial));
  return initial;
};

const saveDB = (db: any) => localStorage.setItem(DB_KEY, JSON.stringify(db));

// --- SHARED COMPONENTS ---

// --- BASE CODE POSTAL EXACT → COMMUNES ---
// Map CP 5 chiffres → communes. Recherche par préfixe dès 2 chiffres tapés.
const CP_DATA: Record<string, string[]> = {
  '01000':['Bourg-en-Bresse'],'01100':['Oyonnax'],'01200':['Bellegarde-sur-Valserine'],
  '01300':['Belley'],'01500':['Ambérieu-en-Bugey'],'01600':['Trévoux'],
  '01700':['Miribel'],'01800':['Meximieux'],
  '02000':['Laon'],'02100':['Saint-Quentin'],'02200':['Soissons'],
  '02300':['Chauny'],'02400':['Château-Thierry'],'02500':['Hirson'],
  '02700':['Tergnier'],
  '03000':['Moulins'],'03100':['Montluçon'],'03200':['Vichy'],
  '03300':['Cusset'],'03400':['Yzeure'],'03500':['Saint-Pourçain-sur-Sioule'],
  '03600':['Commentry'],'03700':['Varennes-sur-Allier'],
  '04000':['Digne-les-Bains'],'04100':['Manosque'],'04200':['Sisteron'],
  '04300':['Forcalquier'],'04400':['Barcelonnette'],
  '05000':['Gap'],'05100':['Briançon'],'05200':['Embrun'],
  '05300':['Laragne-Montéglin'],'05400':['Veynes'],
  '06000':['Nice'],'06100':['Nice'],'06110':['Le Cannet'],
  '06130':['Grasse'],'06140':['Vence'],'06150':['Cannes-la-Bocca'],
  '06160':['Antibes','Juan-les-Pins'],'06180':['Cagnes-sur-Mer'],
  '06200':['Nice'],'06210':['Mandelieu-la-Napoule'],
  '06220':['Vallauris'],'06230':['Villefranche-sur-Mer'],
  '06240':['Beausoleil'],'06250':['Mougins'],'06270':['Villeneuve-Loubet'],
  '06300':['Nice'],'06400':['Cannes'],'06500':['Menton'],
  '06600':['Antibes'],'06700':['Saint-Laurent-du-Var'],
  '07000':['Privas'],'07100':['Annonay'],'07200':['Aubenas'],
  '07300':['Tournon-sur-Rhône'],'07400':['Le Teil'],
  '08000':['Charleville-Mézières'],'08200':['Sedan'],
  '08300':['Rethel'],'08400':['Vouziers'],
  '09000':['Foix'],'09100':['Pamiers'],'09200':['Saint-Girons'],
  '09300':['Lavelanet'],
  '10000':['Troyes'],'10100':['Romilly-sur-Seine'],
  '10200':['Bar-sur-Aube'],'10400':['Nogent-sur-Seine'],
  '11000':['Carcassonne'],'11100':['Narbonne'],
  '11400':['Castelnaudary'],'11500':['Quillan'],
  '12000':['Rodez'],'12100':['Millau'],
  '12200':['Villefranche-de-Rouergue'],'12300':['Decazeville'],
  '13001':['Marseille 1er'],'13002':['Marseille 2e'],'13003':['Marseille 3e'],
  '13004':['Marseille 4e'],'13005':['Marseille 5e'],'13006':['Marseille 6e'],
  '13007':['Marseille 7e'],'13008':['Marseille 8e'],'13009':['Marseille 9e'],
  '13010':['Marseille 10e'],'13011':['Marseille 11e'],'13012':['Marseille 12e'],
  '13013':['Marseille 13e'],'13014':['Marseille 14e'],'13015':['Marseille 15e'],
  '13016':['Marseille 16e'],
  '13080':['Aix-en-Provence'],'13090':['Aix-en-Provence'],
  '13100':['Aix-en-Provence'],'13110':['Port-de-Bouc'],
  '13120':['Gardanne'],'13127':['Vitrolles'],'13128':['Vitrolles'],
  '13130':['Berre-l'Étang'],'13140':['Miramas'],
  '13150':['Tarascon'],'13160':['Châteaurenard'],
  '13170':['Les Pennes-Mirabeau'],'13190':['Allauch'],
  '13200':['Arles'],'13210':['Saint-Rémy-de-Provence'],
  '13220':['Châteauneuf-les-Martigues'],
  '13240':['Septèmes-les-Vallons'],'13260':['Cassis'],
  '13270':['Fos-sur-Mer'],'13300':['Salon-de-Provence'],
  '13310':['Saint-Martin-de-Crau'],'13320':['Bouc-Bel-Air'],
  '13380':['Plan-de-Cuques'],'13390':['Auriol'],
  '13400':['Aubagne'],'13500':['Martigues'],
  '13600':['La Ciotat'],'13700':['Marignane'],
  '13800':['Istres'],'13900':['Salon-de-Provence'],
  '14000':['Caen'],'14100':['Lisieux'],
  '14120':['Hérouville-Saint-Clair'],'14400':['Bayeux'],
  '15000':['Aurillac'],'15200':['Mauriac'],'15100':['Saint-Flour'],
  '16000':['Angoulême'],'16100':['Cognac'],'16400':['La Couronne'],
  '17000':['La Rochelle'],'17100':['Saintes'],
  '17200':['Royan'],'17300':['Rochefort'],
  '18000':['Bourges'],'18100':['Vierzon'],
  '18200':['Saint-Amand-Montrond'],
  '19000':['Tulle'],'19100':['Brive-la-Gaillarde'],
  '19200':['Ussel'],
  '21000':['Dijon'],'21100':['Dijon'],
  '21200':['Beaune'],'21300':['Chenôve'],
  '21600':['Longvic'],
  '22000':['Saint-Brieuc'],'22300':['Lannion'],
  '22600':['Loudéac'],'22200':['Guingamp'],
  '23000':['Guéret'],'23200':['Aubusson'],
  '24000':['Périgueux'],'24100':['Bergerac'],
  '24200':['Sarlat-la-Canéda'],
  '25000':['Besançon'],'25100':['Montbéliard'],
  '25300':['Pontarlier'],
  '26000':['Valence'],'26100':['Romans-sur-Isère'],
  '26200':['Montélimar'],
  '27000':['Évreux'],'27200':['Vernon'],
  '27400':['Louviers'],'27300':['Bernay'],
  '28000':['Chartres'],'28100':['Dreux'],
  '28200':['Châteaudun'],
  '29000':['Quimper'],'29200':['Brest'],
  '29100':['Douarnenez'],'29900':['Concarneau'],
  '30000':['Nîmes'],'30100':['Alès'],
  '30200':['Bagnols-sur-Cèze'],'30700':['Uzès'],
  '31000':['Toulouse'],'31100':['Toulouse'],
  '31200':['Toulouse'],'31300':['Toulouse'],
  '31400':['Toulouse'],'31500':['Toulouse'],
  '31130':['Balma'],'31170':['Tournefeuille'],
  '31250':['Revel'],'31320':['Castanet-Tolosan'],
  '31330':['Grenade'],'31340':['Villemur-sur-Tarn'],
  '31520':['Ramonville-Saint-Agne'],
  '31600':['Muret'],'31650':['Saint-Orens-de-Gameville'],
  '31670':['Labège'],'31700':['Blagnac'],
  '31770':['Colomiers'],'31780':['Castelginest'],
  '31800':['Saint-Gaudens'],'31820':['Pibrac'],
  '31830':['Plaisance-du-Touch'],
  '32000':['Auch'],'32100':['Condom'],
  '32300':['Mirande'],'32400':['Riscle'],
  '33000':['Bordeaux'],'33100':['Bordeaux'],
  '33110':['Le Bouscat'],'33120':['Arcachon'],
  '33125':['La Teste-de-Buch'],
  '33130':['Bègles'],'33140':['Villenave-d'Ornon'],
  '33150':['Cenon'],'33160':['Saint-Médard-en-Jalles'],
  '33170':['Gradignan'],'33190':['La Réole'],
  '33200':['Bordeaux'],'33210':['Langon'],
  '33220':['Sainte-Foy-la-Grande'],
  '33240':['Saint-André-de-Cubzac'],
  '33250':['Pauillac'],'33270':['Floirac'],
  '33290':['Blanquefort'],'33300':['Bordeaux'],
  '33310':['Lormont'],'33320':['Eysines'],
  '33330':['Saint-Émilion'],'33340':['Lesparre-Médoc'],
  '33370':['Yvrac'],'33380':['Mios'],
  '33390':['Blaye'],'33400':['Talence'],
  '33440':['Ambarès-et-Lagrave'],
  '33450':['Saint-Loubès'],'33460':['Macau'],
  '33470':['Gujan-Mestras'],
  '33500':['Libourne'],'33520':['Bruges'],
  '33600':['Pessac'],'33610':['Canéjan'],
  '33700':['Mérignac'],'33800':['Bordeaux'],
  '34000':['Montpellier'],'34070':['Montpellier'],
  '34080':['Montpellier'],'34090':['Montpellier'],
  '34110':['Frontignan'],'34120':['Pézenas'],
  '34130':['Mauguio'],'34140':['Mèze'],
  '34160':['Castries'],'34200':['Sète'],
  '34250':['Palavas-les-Flots'],'34260':['Le Crès'],
  '34300':['Agde'],'34400':['Lunel'],
  '34430':['Saint-Jean-de-Vedas'],
  '34500':['Béziers'],'34540':['Balaruc-les-Bains'],
  '34600':['Bédarieux'],'34700':['Lodève'],
  '34730':['Prades-le-Lez'],
  '34750':['Villeneuve-lès-Maguelone'],
  '34780':['Grabels'],'34800':['Clermont-l'Hérault'],
  '34820':['Teyran'],'34830':['Jacou'],
  '34860':['Pignan'],'34880':['Laverune'],
  '35000':['Rennes'],'35100':['Rennes'],
  '35200':['Rennes'],'35400':['Saint-Malo'],
  '35133':['Fleurigné'],'35136':['Saint-Jacques-de-la-Lande'],
  '35170':['Bruz'],'35230':['Noyal-Châtillon-sur-Seiche'],
  '35235':['Thorigné-Fouillard'],
  '35300':['Fougères'],'35500':['Vitré'],
  '35510':['Cesson-Sévigné'],'35740':['Pace'],
  '36000':['Châteauroux'],'36100':['Issoudun'],
  '36400':['La Châtre'],
  '37000':['Tours'],'37100':['Tours'],
  '37200':['Tours'],'37300':['Joué-lès-Tours'],
  '37400':['Amboise'],'37500':['Chinon'],
  '38000':['Grenoble'],'38100':['Grenoble'],
  '38120':['Saint-Egrève'],'38130':['Échirolles'],
  '38170':['Seyssinet-Pariset'],'38180':['Seyssins'],
  '38240':['Meylan'],'38300':['Bourgoin-Jallieu'],
  '38320':['Eybens'],'38330':['Saint-Ismier'],
  '38340':['Voreppe'],'38400':['Saint-Martin-d'Hères'],
  '38420':['Domène'],'38430':['Moirans'],
  '38500':['Voiron'],'38600':['Fontaine'],
  '38700':['La Tronche'],
  '39000':['Lons-le-Saunier'],'39100':['Dole'],
  '39200':['Saint-Claude'],
  '40000':['Mont-de-Marsan'],'40100':['Dax'],
  '40160':['Parentis-en-Born'],'40200':['Mimizan'],
  '41000':['Blois'],'41100':['Vendôme'],
  '41200':['Romorantin-Lanthenay'],
  '42000':['Saint-Étienne'],'42100':['Saint-Étienne'],
  '42300':['Roanne'],'42400':['Saint-Chamond'],
  '43000':['Le Puy-en-Velay'],'43100':['Brioude'],
  '43120':['Monistrol-sur-Loire'],
  '44000':['Nantes'],'44100':['Nantes'],
  '44110':['Châteaubriant'],'44120':['Vertou'],
  '44130':['Blain'],'44150':['Ancenis-Saint-Géréon'],
  '44160':['Pontchâteau'],'44200':['Nantes'],
  '44220':['Coueron'],'44230':['Saint-Sébastien-sur-Loire'],
  '44240':['La Chapelle-sur-Erdre'],
  '44300':['Nantes'],'44310':['La Baule-Escoublac'],
  '44340':['Bouguenais'],'44350':['Guérande'],
  '44400':['Rezé'],'44470':['Carquefou'],
  '44500':['La Baule-Escoublac'],
  '44600':['Saint-Nazaire'],'44700':['Orvault'],
  '44800':['Saint-Herblain'],
  '44880':['Sautron'],
  '45000':['Orléans'],'45100':['Orléans'],
  '45140':['Ingré'],'45160':['Olivet'],
  '45400':['Fleury-les-Aubrais'],'45760':['Boigny-sur-Bionne'],
  '46000':['Cahors'],'46100':['Figeac'],
  '46200':['Souillac'],'46300':['Gourdon'],
  '47000':['Agen'],'47200':['Marmande'],
  '47300':['Villeneuve-sur-Lot'],
  '48000':['Mende'],'48100':['Marvejols'],
  '48400':['Florac-Trois-Rivières'],
  '49000':['Angers'],'49100':['Angers'],
  '49300':['Cholet'],'49400':['Saumur'],
  '50000':['Saint-Lô'],'50100':['Cherbourg-en-Cotentin'],
  '50400':['Granville'],'50700':['Avranches'],
  '51000':['Châlons-en-Champagne'],
  '51100':['Reims'],'51200':['Épernay'],
  '52000':['Chaumont'],'52100':['Saint-Dizier'],
  '52200':['Langres'],
  '53000':['Laval'],'53100':['Mayenne'],
  '53200':['Château-Gontier-sur-Mayenne'],
  '54000':['Nancy'],'54100':['Nancy'],
  '54130':['Saint-Max'],'54140':['Jarville-la-Malgrange'],
  '54180':['Heillecourt'],'54200':['Toul'],
  '54300':['Lunéville'],'54500':['Vandœuvre-lès-Nancy'],
  '54510':['Tomblaine'],'54520':['Laxou'],
  '55000':['Bar-le-Duc'],'55100':['Verdun'],
  '55200':['Commercy'],'55300':['Saint-Mihiel'],
  '56000':['Vannes'],'56100':['Lorient'],
  '56300':['Pontivy'],'56400':['Auray'],
  '57000':['Metz'],'57100':['Thionville'],
  '57130':['Jouy-aux-Arches'],'57140':['Woippy'],
  '57155':['Marly'],'57200':['Sarreguemines'],
  '57300':['Hagondange'],'57400':['Sarrebourg'],
  '57500':['Saint-Avold'],
  '57600':['Forbach'],
  '57700':['Hayange'],
  '58000':['Nevers'],'58200':['Cosne-Cours-sur-Loire'],
  '58500':['Clamecy'],'58300':['Decize'],
  '59000':['Lille'],'59100':['Roubaix'],
  '59110':['La Madeleine'],'59120':['Loos'],
  '59130':['Lambersart'],'59140':['Dunkerque'],
  '59150':['Wattrelos'],'59155':['Faches-Thumesnil'],
  '59160':['Lomme'],'59170':['Croix'],
  '59200':['Tourcoing'],'59210':['Coudekerque-Branche'],
  '59220':['Denain'],'59223':['Roncq'],
  '59230':['Saint-Amand-les-Eaux'],
  '59240':['Dunkerque'],'59250':['Halluin'],
  '59260':['Hellemmes-Lille'],'59270':['Bailleul'],
  '59280':['Armentières'],'59290':['Wasquehal'],
  '59300':['Valenciennes'],'59350':['Saint-André-lez-Lille'],
  '59370':['Mons-en-Barœul'],'59380':['Bergues'],
  '59390':['Lys-lez-Lannoy'],'59400':['Cambrai'],
  '59410':['Anzin'],'59420':['Mouvaux'],
  '59500':['Douai'],'59510':['Hem'],
  '59520':['Marquette-lez-Lille'],
  '59600':['Maubeuge'],'59650':['Villeneuve-d'Ascq'],
  '59700':['Marcq-en-Barœul'],
  '59760':['Grande-Synthe'],'59770':['Marly'],
  '59800':['Lille'],'59810':['Lesquin'],
  '59880':['Saint-Saulve'],
  '60000':['Beauvais'],'60100':['Creil'],
  '60200':['Compiègne'],'60300':['Senlis'],
  '61000':['Alençon'],'61100':['Flers'],
  '61200':['Argentan'],
  '62000':['Arras'],'62100':['Calais'],
  '62110':['Hénin-Beaumont'],'62190':['Lillers'],
  '62200':['Boulogne-sur-Mer'],'62300':['Lens'],
  '62400':['Béthune'],'62500':['Saint-Omer'],
  '62700':['Bruay-la-Buissière'],
  '63000':['Clermont-Ferrand'],'63100':['Clermont-Ferrand'],
  '63110':['Beaumont'],'63118':['Cébazat'],
  '63170':['Aubière'],'63200':['Riom'],
  '63300':['Thiers'],'63500':['Issoire'],
  '63700':['Pont-du-Château'],
  '64000':['Pau'],'64100':['Bayonne'],
  '64200':['Biarritz'],'64600':['Anglet'],
  '65000':['Tarbes'],'65100':['Lourdes'],
  '65200':['Bagnères-de-Bigorre'],
  '66000':['Perpignan'],'66100':['Perpignan'],
  '66140':['Canet-en-Roussillon'],'66240':['Saint-Estève'],
  '67000':['Strasbourg'],'67100':['Strasbourg'],
  '67130':['Schiltigheim'],'67140':['Barr'],
  '67200':['Strasbourg'],'67300':['Schiltigheim'],
  '67380':['Lingolsheim'],'67400':['Illkirch-Graffenstaden'],
  '67500':['Haguenau'],'67600':['Sélestat'],
  '67700':['Saverne'],'67800':['Bischheim'],
  '68000':['Colmar'],'68100':['Mulhouse'],
  '68110':['Illzach'],'68200':['Mulhouse'],
  '68300':['Saint-Louis'],'68400':['Riedisheim'],
  '69001':['Lyon 1er'],'69002':['Lyon 2e'],'69003':['Lyon 3e'],
  '69004':['Lyon 4e'],'69005':['Lyon 5e'],'69006':['Lyon 6e'],
  '69007':['Lyon 7e'],'69008':['Lyon 8e'],'69009':['Lyon 9e'],
  '69100':['Villeurbanne'],'69110':['Sainte-Foy-lès-Lyon'],
  '69120':['Vaulx-en-Velin'],'69122':['Caluire-et-Cuire'],
  '69130':['Écully'],'69140':['Rillieux-la-Pape'],
  '69150':['Décines-Charpieu'],'69160':['Tassin-la-Demi-Lune'],
  '69170':['Tarare'],'69190':['Saint-Fons'],
  '69200':['Vénissieux'],'69230':['Saint-Genis-Laval'],
  '69240':['Thizy-les-Bourgs'],'69260':['Charbonnières-les-Bains'],
  '69270':['Fontaines-sur-Saône'],'69280':['Marcy-l'Étoile'],
  '69290':['Grézieu-la-Varenne'],
  '69300':['Caluire-et-Cuire'],'69310':['Pierre-Bénite'],
  '69320':['Feyzin'],'69330':['Meyzieu'],
  '69340':['Francheville'],'69350':['La Mulatière'],
  '69360':['Solaize'],'69370':['Saint-Didier-au-Mont-d'Or'],
  '69380':['Lozanne'],'69390':['Vourles'],
  '69400':['Villefranche-sur-Saône'],'69410':['Champagne-au-Mont-d'Or'],
  '69420':['Condrieu'],'69430':['Beaujeu'],
  '69440':['Mornant'],'69450':['Saint-Cyr-au-Mont-d'Or'],
  '69460':['Blacé'],'69470':['Cours-la-Ville'],
  '69480':['Anse'],'69500':['Bron'],
  '69520':['Grigny'],'69530':['Brignais'],
  '69540':['Irigny'],'69550':['Amplepuis'],
  '69560':['Sainte-Colombe'],'69570':['Dardilly'],
  '69580':['Sathonay-Camp'],
  '69600':['Oullins'],'69620':['Le Bois-d'Oingt'],
  '69630':['Chaponost'],'69640':['Lacenas'],
  '69660':['Collonges-au-Mont-d'Or'],'69670':['Vaugneray'],
  '69680':['Chasselay'],'69700':['Givors'],
  '69720':['Saint-Bonnet-de-Mure'],
  '69730':['Genay'],'69740':['Genas'],
  '69760':['Limonest'],'69780':['Mions'],
  '69800':['Saint-Priest'],'69960':['Corbas'],
  '69970':['Chaponnay'],
  '70000':['Vesoul'],'70200':['Lure'],
  '70100':['Gray'],'70300':['Luxeuil-les-Bains'],
  '71000':['Mâcon'],'71100':['Chalon-sur-Saône'],
  '71200':['Le Creusot'],'71300':['Montceau-les-Mines'],
  '72000':['Le Mans'],'72100':['Le Mans'],
  '72200':['La Flèche'],'72300':['Sablé-sur-Sarthe'],
  '73000':['Chambéry'],'73100':['Aix-les-Bains'],
  '73200':['Albertville'],'73300':['Saint-Jean-de-Maurienne'],
  '74000':['Annecy'],'74100':['Annemasse'],
  '74200':['Thonon-les-Bains'],'74300':['Cluses'],
  '75001':['Paris 1er'],'75002':['Paris 2e'],'75003':['Paris 3e'],
  '75004':['Paris 4e'],'75005':['Paris 5e'],'75006':['Paris 6e'],
  '75007':['Paris 7e'],'75008':['Paris 8e'],'75009':['Paris 9e'],
  '75010':['Paris 10e'],'75011':['Paris 11e'],'75012':['Paris 12e'],
  '75013':['Paris 13e'],'75014':['Paris 14e'],'75015':['Paris 15e'],
  '75016':['Paris 16e'],'75017':['Paris 17e'],'75018':['Paris 18e'],
  '75019':['Paris 19e'],'75020':['Paris 20e'],
  '76000':['Rouen'],'76100':['Rouen'],
  '76120':['Le Grand-Quevilly'],'76130':['Mont-Saint-Aignan'],
  '76140':['Le Petit-Quevilly'],'76150':['Maromme'],
  '76200':['Dieppe'],'76210':['Bolbec'],
  '76250':['Déville-lès-Rouen'],
  '76300':['Sotteville-lès-Rouen'],
  '76400':['Fécamp'],'76410':['Cléon'],
  '76420':['Bihorel'],'76500':['Elbeuf'],
  '76600':['Le Havre'],'76620':['Le Havre'],
  '76700':['Harfleur'],'76800':['Saint-Étienne-du-Rouvray'],
  '77000':['Melun'],'77100':['Meaux'],
  '77110':['Coulommiers'],'77130':['Montereau-Fault-Yonne'],
  '77140':['Nemours'],'77160':['Provins'],
  '77170':['Brie-Comte-Robert'],
  '77180':['Combs-la-Ville'],'77185':['Lognes'],
  '77200':['Torcy'],'77210':['Avon'],
  '77220':['Tournan-en-Brie'],
  '77230':['Dammartin-en-Goële'],
  '77270':['Villeparisis'],'77280':['Othis'],
  '77290':['Mitry-Mory'],'77300':['Fontainebleau'],
  '77310':['Saint-Fargeau-Ponthierry'],
  '77330':['Ozoir-la-Ferrière'],
  '77340':['Pontault-Combault'],
  '77350':['Le Mée-sur-Seine'],
  '77360':['Vaires-sur-Marne'],
  '77400':['Lagny-sur-Marne'],
  '77410':['Claye-Souilly'],
  '77420':['Champs-sur-Marne'],
  '77500':['Chelles'],'77600':['Bussy-Saint-Georges'],
  '77700':['Serris'],
  '78000':['Versailles'],'78100':['Saint-Germain-en-Laye'],
  '78110':['Le Vésinet'],'78120':['Rambouillet'],
  '78130':['Les Mureaux'],
  '78140':['Vélizy-Villacoublay'],
  '78150':['Le Chesnay-Rocquencourt'],
  '78160':['Marly-le-Roi'],
  '78170':['La Celle-Saint-Cloud'],
  '78180':['Montigny-le-Bretonneux'],
  '78190':['Trappes'],'78200':['Mantes-la-Jolie'],
  '78210':['Saint-Cyr-l'École'],
  '78220':['Viroflay'],'78230':['Le Pecq'],
  '78240':['Chambourcy'],
  '78250':['Meulan-en-Yvelines'],
  '78260':['Achères'],'78280':['Guyancourt'],
  '78290':['Croissy-sur-Seine'],
  '78300':['Poissy'],'78310':['Coignières'],
  '78320':['La Verrière'],
  '78330':['Fontenay-le-Fleury'],
  '78340':['Les Clayes-sous-Bois'],
  '78350':['Jouy-en-Josas'],
  '78360':['Montesson'],'78370':['Plaisir'],
  '78380':['Bougival'],'78390':['Bois-d'Arcy'],
  '78400':['Chatou'],'78410':['Aubergenville'],
  '78500':['Sartrouville'],
  '78600':['Maisons-Laffitte'],
  '78700':['Conflans-Sainte-Honorine'],
  '78800':['Houilles'],
  '79000':['Niort'],'79100':['Thouars'],
  '79200':['Bressuire'],'79300':['Bressuire'],
  '80000':['Amiens'],'80100':['Abbeville'],
  '80200':['Péronne'],'80300':['Albert'],
  '81000':['Albi'],'81100':['Castres'],
  '81200':['Mazamet'],'81600':['Gaillac'],
  '82000':['Montauban'],'82100':['Castelsarrasin'],
  '82200':['Moissac'],'82300':['Caussade'],
  '83000':['Toulon'],'83100':['Toulon'],
  '83100':['Toulon'],'83200':['Toulon'],
  '83300':['Draguignan'],'83370':['Fréjus'],
  '83400':['Hyères'],'83600':['Fréjus'],
  '83700':['Saint-Raphaël'],
  '84000':['Avignon'],'84100':['Orange'],
  '84200':['Carpentras'],'84300':['Cavaillon'],
  '84400':['Apt'],
  '85000':['La Roche-sur-Yon'],
  '85100':['Les Sables-d'Olonne'],
  '85300':['Challans'],
  '85200':['Fontenay-le-Comte'],
  '86000':['Poitiers'],'86100':['Châtellerault'],
  '86200':['Loudun'],
  '87000':['Limoges'],'87100':['Limoges'],
  '87200':['Saint-Junien'],
  '88000':['Épinal'],'88100':['Saint-Dié-des-Vosges'],
  '88200':['Remiremont'],'88400':['Gérardmer'],
  '89000':['Auxerre'],'89100':['Sens'],
  '89200':['Avallon'],'89300':['Joigny'],
  '90000':['Belfort'],'90100':['Delle'],
  '90110':['Beaucourt'],
  '91000':['Évry-Courcouronnes'],
  '91100':['Corbeil-Essonnes'],
  '91120':['Palaiseau'],'91130':['Ris-Orangis'],
  '91160':['Longjumeau'],'91170':['Viry-Châtillon'],
  '91180':['Saint-Germain-lès-Arpajon'],
  '91190':['Gif-sur-Yvette'],
  '91200':['Athis-Mons'],'91210':['Draveil'],
  '91220':['Brétigny-sur-Orge'],
  '91230':['Montgeron'],
  '91240':['Saint-Michel-sur-Orge'],
  '91270':['Vigneux-sur-Seine'],
  '91300':['Massy'],'91310':['Montlhéry'],
  '91320':['Wissous'],'91330':['Yerres'],
  '91350':['Grigny'],
  '91370':['Verrières-le-Buisson'],
  '91380':['Chilly-Mazarin'],
  '91390':['Morsang-sur-Orge'],
  '91400':['Orsay'],'91420':['Morangis'],
  '91430':['Igny'],'91440':['Bures-sur-Yvette'],
  '91450':['Soisy-sur-Seine'],
  '91460':['Marcoussis'],'91470':['Limours'],
  '91500':['Brunoy'],'91540':['Mennecy'],
  '91550':['Paray-Vieille-Poste'],
  '91580':['Étréchy'],
  '91600':['Savigny-sur-Orge'],
  '91700':['Fleury-Mérogis'],
  '92000':['Nanterre'],'92100':['Boulogne-Billancourt'],
  '92110':['Clichy'],'92120':['Montrouge'],
  '92130':['Issy-les-Moulineaux'],'92140':['Clamart'],
  '92150':['Suresnes'],'92160':['Antony'],
  '92170':['Vanves'],'92190':['Meudon'],
  '92200':['Neuilly-sur-Seine'],'92210':['Saint-Cloud'],
  '92220':['Bagneux'],'92230':['Gennevilliers'],
  '92240':['Malakoff'],
  '92250':['La Garenne-Colombes'],
  '92260':['Fontenay-aux-Roses'],
  '92270':['Bois-Colombes'],
  '92290':['Châtenay-Malabry'],
  '92300':['Levallois-Perret'],
  '92310':['Sèvres'],'92320':['Châtillon'],
  '92330':['Sceaux'],'92340':['Bourg-la-Reine'],
  '92350':['Le Plessis-Robinson'],
  '92370':['Chaville'],'92380':['Garches'],
  '92400':['Courbevoie'],
  '92500':['Rueil-Malmaison'],
  '92600':['Asnières-sur-Seine'],
  '92700':['Colombes'],'92800':['Puteaux'],
  '93000':['Bobigny'],'93100':['Montreuil'],
  '93110':['Rosny-sous-Bois'],
  '93120':['La Courneuve'],
  '93130':['Noisy-le-Sec'],'93140':['Bondy'],
  '93150':['Le Blanc-Mesnil'],
  '93160':['Noisy-le-Grand'],'93170':['Bagnolet'],
  '93180':['Livry-Gargan'],
  '93200':['Saint-Denis'],
  '93220':['Gagny'],'93230':['Romainville'],
  '93240':['Stains'],'93250':['Villemomble'],
  '93260':['Les Lilas'],'93270':['Sevran'],
  '93290':['Tremblay-en-France'],
  '93300':['Aubervilliers'],
  '93310':['Le Pré-Saint-Gervais'],
  '93320':['Les Pavillons-sous-Bois'],
  '93330':['Neuilly-sur-Marne'],
  '93340':['Le Raincy'],'93350':['Le Bourget'],
  '93360':['Neuilly-Plaisance'],
  '93370':['Montfermeil'],
  '93380':['Pierrefitte-sur-Seine'],
  '93390':['Clichy-sous-Bois'],
  '93400':['Saint-Ouen-sur-Seine'],
  '93420':['Villepinte'],
  '93500':['Pantin'],'93600':['Aulnay-sous-Bois'],
  '93700':['Drancy'],
  '93800':['Épinay-sur-Seine'],
  '94000':['Créteil'],'94100':['Saint-Maur-des-Fossés'],
  '94110':['Arcueil'],'94120':['Fontenay-sous-Bois'],
  '94130':['Nogent-sur-Marne'],
  '94140':['Alfortville'],'94160':['Saint-Mandé'],
  '94170':['Le Perreux-sur-Marne'],
  '94180':['Ivry-sur-Seine'],
  '94190':['Villeneuve-Saint-Georges'],
  '94200':['Ivry-sur-Seine'],
  '94220':['Charenton-le-Pont'],
  '94230':['Cachan'],
  '94240':['L'Haÿ-les-Roses'],
  '94250':['Gentilly'],'94260':['Fresnes'],
  '94270':['Kremlin-Bicêtre'],
  '94290':['Villeneuve-le-Roi'],
  '94300':['Vincennes'],'94310':['Orly'],
  '94320':['Thiais'],
  '94340':['Joinville-le-Pont'],
  '94370':['Sucy-en-Brie'],
  '94380':['Bonneuil-sur-Marne'],
  '94400':['Vitry-sur-Seine'],
  '94420':['Le Plessis-Trévise'],
  '94430':['Chennevières-sur-Marne'],
  '94500':['Champigny-sur-Marne'],
  '94550':['Chevilly-Larue'],
  '94600':['Choisy-le-Roi'],
  '94700':['Maisons-Alfort'],
  '94800':['Villejuif'],
  '95000':['Cergy'],'95100':['Argenteuil'],
  '95110':['Sannois'],'95120':['Ermont'],
  '95130':['Franconville'],
  '95140':['Garges-lès-Gonesse'],
  '95150':['Taverny'],
  '95160':['Montmorency'],
  '95170':['Deuil-la-Barre'],
  '95200':['Sarcelles'],
  '95210':['Saint-Gratien'],
  '95220':['Herblay-sur-Seine'],
  '95230':['Soisy-sous-Montmorency'],
  '95240':['Cormeilles-en-Parisis'],
  '95260':['Beaumont-sur-Oise'],
  '95280':['Jouy-le-Moutier'],
  '95290':['L'Isle-Adam'],
  '95300':['Pontoise'],
  '95310':['Saint-Ouen-l'Aumône'],
  '95320':['Saint-Leu-la-Forêt'],
  '95330':['Domont'],
  '95340':['Persan'],
  '95350':['Saint-Brice-sous-Forêt'],
  '95360':['Montmagny'],
  '95370':['Montmorency'],
  '95380':['Louvres'],
  '95390':['Saint-Prix'],
  '95400':['Arnouville'],
  '95410':['Groslay'],
  '95440':['Écouen'],
  '95450':['Vauréal'],
  '95460':['Ezanville'],
  '95470':['Survilliers'],
  '95490':['Vauréal'],
  '95500':['Gonesse'],
  '95520':['Osny'],
  '95540':['Méry-sur-Oise'],
  '95570':['Andilly'],
  '95600':['Eaubonne'],
  '95610':['Éragny'],
  '95640':['Marines'],
  '95650':['Puiseux-Pontoise'],
  '95660':['Champagne-sur-Oise'],
  '95670':['Marly-la-Ville'],
  '95700':['Roissy-en-France'],
  '95800':['Cergy'],
  '95880':['Enghien-les-Bains'],
  '97100':['Basse-Terre'],'97110':['Pointe-à-Pitre'],
  '97112':['Grand-Bourg'],'97122':['Baie-Mahault'],
  '97123':['Le Gosier'],'97130':['Capesterre-Belle-Eau'],
  '97132':['Les Abymes'],'97140':['Capesterre-de-Marie-Galante'],
  '97141':['Sainte-Anne'],'97160':['Le Moule'],
  '97170':['Petit-Bourg'],'97180':['Sainte-Anne'],
  '97190':['Le Gosier'],
  '97200':['Fort-de-France'],'97210':['Le François'],
  '97212':['Saint-Joseph'],'97213':['Le Gros-Morne'],
  '97214':['Le Lorrain'],'97215':['Le Marigot'],
  '97216':['Le Marin'],'97218':['Sainte-Marie'],
  '97220':['Trinité'],'97223':['Le Diamant'],
  '97224':['Ducos'],'97225':['Sainte-Luce'],
  '97226':['Rivière-Pilote'],'97227':['Sainte-Anne'],
  '97228':['Rivière-Salée'],
  '97229':['Les Trois-Îlets'],
  '97230':['Sainte-Marie'],'97231':['Le Robert'],
  '97232':['Le Lamentin'],
  '97233':['Schœlcher'],
  '97250':['Saint-Pierre'],
  '97270':['Saint-Esprit'],
  '97280':['Vauclin'],
  '97290':['Le Marin'],
  '97300':['Cayenne'],'97310':['Kourou'],
  '97320':['Saint-Laurent-du-Maroni'],
  '97351':['Macouria'],
  '97353':['Matoury'],
  '97354':['Rémire-Montjoly'],
  '97355':['Sinnamary'],
  '97360':['Mana'],
  '97400':['Saint-Denis'],'97410':['Saint-Benoît'],
  '97417':['Saint-André'],
  '97420':['Le Port'],
  '97430':['Le Tampon'],
  '97434':['Saint-Gilles-les-Bains'],
  '97436':['Saint-Leu'],
  '97437':['Sainte-Marie'],
  '97440':['Saint-André'],
  '97450':['Saint-Louis'],
  '97460':['Saint-Paul'],
  '97470':['Saint-Benoît'],
  '97480':['Saint-Joseph'],
  '97490':['Sainte-Clotilde'],
};

// Recherche par préfixe CP — retourne les communes correspondantes
function getVillesForCP(cp: string): string[] {
  if (!cp || cp.length < 2) return [];
  const clean = cp.replace(/\D/g, '');
  if (clean.length === 5) {
    // CP exact → retourne les communes de ce CP
    return CP_DATA[clean] || [];
  }
  // CP partiel → retourne toutes les communes dont le CP commence par ce préfixe
  const villes = new Set<string>();
  Object.entries(CP_DATA).forEach(([code, communes]) => {
    if (code.startsWith(clean)) communes.forEach(v => villes.add(v));
  });
  return Array.from(villes).sort();
}

// Composant Code Postal → sélection de ville
const CodePostalSelect: React.FC<{
  cp: string;
  ville: string;
  onCPChange: (cp: string) => void;
  onVilleChange: (ville: string) => void;
  accentColor?: string;
  required?: boolean;
}> = ({ cp, ville, onCPChange, onVilleChange, accentColor = 'orange', required = false }) => {
  const villes = getVillesForCP(cp);
  const focusCls = accentColor === 'emerald' ? 'focus:border-emerald-500' : 'focus:border-orange-500';
  const inputCls = `w-full bg-slate-950 border border-white/10 p-4 rounded-2xl ${focusCls} transition-all font-bold`;
  const [showFree, setShowFree] = React.useState(false);

  // Quand le CP change, reset le mode libre
  React.useEffect(() => { setShowFree(false); }, [cp]);

  return (
    <div className="grid grid-cols-2 gap-4">
      <div>
        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Code Postal</label>
        <input
          type="text"
          placeholder="Ex: 69000"
          maxLength={5}
          value={cp}
          onChange={e => { onCPChange(e.target.value.replace(/\D/g, '')); onVilleChange(''); }}
          className={inputCls}
          required={required}
        />
      </div>
      <div>
        <div className="flex items-center justify-between mb-2">
          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Ville</label>
          {villes.length > 0 && (
            <button
              type="button"
              onClick={() => { setShowFree(f => !f); onVilleChange(''); }}
              className="text-[9px] font-black uppercase text-slate-500 hover:text-slate-300 transition-colors"
            >
              {showFree ? 'Choisir liste' : 'Saisie libre'}
            </button>
          )}
        </div>
        {villes.length > 0 && !showFree ? (
          <select
            value={ville}
            onChange={e => onVilleChange(e.target.value)}
            className={inputCls + ' cursor-pointer'}
            required={required}
          >
            <option value="">-- Sélectionner --</option>
            {villes.map(v => <option key={v} value={v}>{v}</option>)}
          </select>
        ) : (
          <input
            type="text"
            placeholder={cp.length >= 2 ? 'Saisir la ville' : 'Entrez le CP d\'abord'}
            value={ville}
            onChange={e => onVilleChange(e.target.value)}
            className={`${inputCls} ${cp.length < 2 ? 'opacity-40 pointer-events-none' : ''}`}
            required={required}
            readOnly={cp.length < 2}
          />
        )}
      </div>
    </div>
  );
};

// Composant multi-CV avec analyse IA
type CVFile = { id: string; nom: string; titre?: string; base64: string; date: string };

const CVUpload: React.FC<{
  cvList: CVFile[];
  onCVListChange: (list: CVFile[]) => void;
  onAnalyzeCV?: (base64: string, nom: string) => void;
  isAnalyzing?: boolean;
}> = ({ cvList, onCVListChange, onAnalyzeCV, isAnalyzing = false }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        const newCV: CVFile = {
          id: 'cv' + Date.now() + Math.random(),
          nom: file.name,
          base64,
          date: new Date().toLocaleDateString('fr-FR'),
        };
        onCVListChange([...cvList, newCV]);
      };
      reader.readAsDataURL(file);
    });
    // Reset input pour permettre re-upload du même fichier
    e.target.value = '';
  };

  const removeCV = (id: string) => {
    onCVListChange(cvList.filter(cv => cv.id !== id));
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest ml-1">
          CV ({cvList.length} fichier{cvList.length > 1 ? 's' : ''})
        </label>
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="bg-[#FF731D] text-white text-[10px] font-black uppercase px-4 py-2 rounded-2xl hover:bg-orange-500 transition-all"
        >
          + Ajouter un CV
        </button>
      </div>

      {cvList.length === 0 && (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-white/10 rounded-[1.5rem] p-8 text-center cursor-pointer hover:border-orange-500/40 transition-all"
        >
          <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Aucun CV chargé</p>
          <p className="text-slate-500 text-[10px] mt-1">Cliquez pour ajouter un CV (PDF)</p>
        </div>
      )}

      {cvList.map(cv => (
        <div key={cv.id} className="flex items-center justify-between bg-slate-800/60 p-4 rounded-[1.5rem] border border-white/10">
          <div className="flex items-center gap-3 min-w-0">
            <div className="bg-red-500/20 border border-red-500/30 p-2 rounded-lg shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-white truncate">{cv.nom}</p>
              <p className="text-[10px] text-slate-400">Ajouté le {cv.date}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {onAnalyzeCV && (
              <button
                type="button"
                onClick={() => onAnalyzeCV(cv.base64, cv.nom)}
                disabled={isAnalyzing}
                className="bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 text-[9px] font-black uppercase px-3 py-1.5 rounded-lg hover:bg-emerald-600/30 transition-all disabled:opacity-50"
              >
                {isAnalyzing ? '...' : 'Analyser IA'}
              </button>
            )}
            <button
              type="button"
              onClick={() => removeCV(cv.id)}
              className="text-slate-500 hover:text-red-400 transition-colors p-1"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>
      ))}

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".pdf,.doc,.docx"
        multiple
        className="hidden"
      />
    </div>
  );
};

const PhotoUpload: React.FC<{ currentUrl?: string; onPhotoChange: (url: string) => void }> = ({ currentUrl, onPhotoChange }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState(currentUrl || '');

  useEffect(() => {
    if (currentUrl) setPreview(currentUrl);
  }, [currentUrl]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPreview(base64);
        onPhotoChange(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative group">
        <div className="w-32 h-32 rounded-full bg-slate-900 border-4 border-[#FF731D] flex items-center justify-center overflow-hidden shadow-2xl transition-transform group-hover:scale-105">
          {preview ? (
            <img src={preview} alt="Profile" className="w-full h-full object-cover" />
          ) : (
            <div className="text-4xl text-slate-700 font-black">?</div>
          )}
        </div>
        <button 
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="absolute bottom-0 right-0 bg-[#FF731D] p-3 rounded-full border-4 border-slate-950 text-white shadow-xl active:scale-90 transition-all"
          title="Prendre une photo ou choisir dans la galerie"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        </button>
      </div>
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        accept="image/*" 
        capture="user" 
        className="hidden" 
      />
      <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Photo de profil (Optionnel)</p>
    </div>
  );
};

const ToggleSwitch: React.FC<{ checked: boolean; onChange: () => void; label: string }> = ({ checked, onChange, label }) => {
  return (
    <div className="flex items-center justify-between gap-4 p-4 bg-slate-900/70 rounded-[1.5rem] border border-white/10">
      <span className="text-xs font-black uppercase tracking-widest text-slate-400">{label}</span>
      <button 
        type="button"
        onClick={onChange}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${checked ? 'bg-emerald-600' : 'bg-slate-700'}`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${checked ? 'translate-x-6' : 'translate-x-1'}`}
        />
      </button>
    </div>
  );
};

// Composant champ mot de passe avec bouton afficher/masquer
const PasswordInput: React.FC<{
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  autoComplete?: string;
  required?: boolean;
  className?: string;
}> = ({ value, onChange, placeholder = '••••••••', autoComplete = 'current-password', required = false, className = '' }) => {
  const [show, setShow] = useState(false);
  const base = `w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:outline-none focus:border-orange-500 font-bold pr-12 ${className}`;
  return (
    <div className="relative">
      <input
        type={show ? 'text' : 'password'}
        autoComplete={autoComplete}
        value={value}
        onChange={e => onChange(e.target.value)}
        className={base}
        placeholder={placeholder}
        required={required}
      />
      <button
        type="button"
        onClick={() => setShow(s => !s)}
        className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
        tabIndex={-1}
      >
        {show ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 4.411m0 0L21 21" />
          </svg>
        ) : (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        )}
      </button>
    </div>
  );
};

// --- VIEWS ---

const LandingView: React.FC<{ onStart: (role: TypeUtilisateur) => void }> = ({ onStart }) => (
  <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-700" style={{ background: '#0f172a', position: 'relative', overflow: 'hidden' }}>
    {/* Halo orange */}
    <div style={{ position: 'absolute', top: '20%', left: '50%', transform: 'translate(-50%,-50%)', width: 500, height: 280, background: 'radial-gradient(ellipse, rgba(255,77,0,0.12) 0%, transparent 68%)', pointerEvents: 'none' }} />

    <Logo size="xl" className="mb-6" />

    {/* Badge statut */}
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '5px 14px', borderRadius: 100, background: '#14532D', border: '2px solid #166534', marginBottom: 28 }}>
      <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#22C55E', flexShrink: 0 }} />
      <span style={{ fontSize: 12, color: '#86EFAC', fontWeight: 700, letterSpacing: '0.05em' }}>Plateforme active · 1 247 talents</span>
    </div>

    {/* Titre blanc sur fond marine */}
    <h1 className="text-5xl md:text-7xl font-black mb-5 tracking-tighter italic uppercase leading-none" style={{ color: '#F1F5F9' }}>
      Le recrutement <br />
      <span style={{ color: '#FF731D' }}>réinventé.</span>
    </h1>
    <p className="max-w-md mb-12 font-medium text-base" style={{ color: '#94A3B8', lineHeight: 1.7 }}>
      Sur <span className="text-white font-black italic">Talentbook</span>, ce sont les entreprises qui viennent à vous.
      Mettez en avant vos compétences et laissez la magie opérer.
    </p>

    {/* BOUTONS — fond brun-sombre + texte orange + bordure orange */}
    <div className="w-full max-w-sm flex flex-col gap-3">
      <button
        onClick={() => onStart('candidat')}
        className="w-full py-5 rounded-[1.5rem] font-black text-xl active:scale-95 transition-all"
        style={{ background: '#FF731D', color: 'white' }}
        onMouseOver={e => { e.currentTarget.style.background = '#3D2010' }}
        onMouseOut={e => { e.currentTarget.style.background = '#2D1A0A' }}
      >
        Je suis un Talent →
      </button>
      <button
        onClick={() => onStart('entreprise')}
        className="w-full py-5 rounded-[1.5rem] font-black text-xl active:scale-95 transition-all"
        style={{ background: '#FF731D', color: 'white' }}
        onMouseOver={e => { e.currentTarget.style.background = '#3D2010' }}
        onMouseOut={e => { e.currentTarget.style.background = '#2D1A0A' }}
      >
        Je recrute →
      </button>
    </div>

    {/* Stats */}
    <div className="mt-12 flex gap-10" style={{ opacity: 0.85 }}>
      <div className="text-center">
        <div className="font-black text-2xl italic uppercase" style={{ color: '#FF731D' }}>1 247</div>
        <div style={{ fontSize: 10, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 2 }}>Talents</div>
      </div>
      <div style={{ width: 1, background: '#3B4F6E' }} />
      <div className="text-center">
        <div className="font-black text-2xl italic uppercase" style={{ color: '#F1F5F9' }}>312</div>
        <div style={{ fontSize: 10, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 2 }}>Entreprises</div>
      </div>
      <div style={{ width: 1, background: '#3B4F6E' }} />
      <div className="text-center">
        <div className="font-black text-2xl italic uppercase" style={{ color: '#22C55E' }}>89%</div>
        <div style={{ fontSize: 10, color: '#64748B', textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 2 }}>Satisfaction</div>
      </div>
    </div>
  </div>
);

const LoginView: React.FC<{ role: TypeUtilisateur | null, onLogin: (u: Utilisateur) => void, onSocialAuth: (provider: any) => void, onSwitchToSignup: () => void, onBack: () => void }> = ({ role, onLogin, onSocialAuth, onSwitchToSignup, onBack }) => {
  const [loginInput, setLoginInput] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const db = getDB();
    const u = db.users.find((x: any) => 
      (x.email.toLowerCase() === loginInput.toLowerCase() || x.identifiant.toLowerCase() === loginInput.toLowerCase()) && 
      x.password === password
    );
    if (u) onLogin(u);
    else setError('Identifiants incorrects.');
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 max-w-md mx-auto">
      <div className="w-full bg-slate-900/70 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl animate-in slide-in-from-bottom-8 duration-500">
        <Logo size="md" className="mb-8 mx-auto" />
        <h2 className="text-2xl font-black text-center mb-8 uppercase italic tracking-tighter">
          Connexion <BrandText text="Talentbook" />
        </h2>
        {role && (
          <p className="text-center text-[10px] font-black uppercase text-slate-400 tracking-widest mb-6 -mt-6">
            Espace {role}
          </p>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Email ou Identifiant</label>
            <input 
              type="text" 
              autoComplete="username"
              value={loginInput} 
              onChange={e => setLoginInput(e.target.value)} 
              className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:outline-none focus:border-orange-500 font-bold" 
              placeholder="Identifiant (ex: candidat1)"
              required 
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Mot de passe</label>
            <PasswordInput value={password} onChange={setPassword} autoComplete="current-password" required />
          </div>
          {error && <p className="text-red-500 text-xs font-black uppercase text-center">{error}</p>}
          <button type="submit" className="w-full bg-[#FF731D] py-5 rounded-[1.5rem] font-black text-lg hover:bg-orange-500 transition-all">SE CONNECTER</button>
        </form>

        <div className="mt-8 space-y-4">
          <div className="flex items-center gap-4 text-slate-400 text-[10px] font-black uppercase">
            <div className="flex-1 border-t border-white/10"></div>
            <span>OU</span>
            <div className="flex-1 border-t border-white/10"></div>
          </div>
          <div className="grid grid-cols-1 gap-3">
            <button onClick={() => onSocialAuth('google')} className="bg-white text-slate-950 py-3 rounded-2xl hover:bg-slate-100 transition-all flex items-center justify-center gap-3 font-black text-xs uppercase">
               <img src="https://www.google.com/favicon.ico" className="w-4 h-4" alt="G" />
               Google
            </button>
            <div className="grid grid-cols-2 gap-2">
                <button onClick={() => onSocialAuth('facebook')} className="bg-[#1877F2] text-white py-3 rounded-2xl hover:opacity-90 transition-all flex items-center justify-center gap-2 font-black text-[10px] uppercase">
                    Facebook
                </button>
                <button onClick={() => onSocialAuth('linkedin')} className="bg-[#0077B5] text-white py-3 rounded-2xl hover:opacity-90 transition-all flex items-center justify-center gap-2 font-black text-[10px] uppercase">
                    LinkedIn
                </button>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center space-y-4">
          <p className="text-slate-400 text-xs font-bold uppercase">Pas de compte ? <button onClick={onSwitchToSignup} className="text-orange-500 font-black">S'inscrire</button></p>
          <button onClick={onBack} className="text-slate-400 text-[10px] font-black uppercase">Retour</button>
        </div>
      </div>
    </div>
  );
};

const SignupView: React.FC<{ role: TypeUtilisateur | null, initialData?: any, onSignup: (u: Utilisateur, p: ProfilCandidat) => void, onSwitchToLogin: () => void, onBack: () => void, onShowLegal?: (page: 'cgu' | 'confidentialite') => void }> = ({ role, initialData, onSignup, onSwitchToLogin, onBack, onShowLegal }) => {
  const [formData, setFormData] = useState({
    nom: initialData?.nom || '', 
    prenom: initialData?.prenom || '', 
    identifiant: '', 
    date_naissance: '', 
    genre: 'Homme' as Genre, 
    telephone: initialData?.telephone || '', 
    email: initialData?.email || '', 
    password: '', 
    photo_url: initialData?.photo_url || ''
  });
  const [idError, setIdError] = useState('');
  const [isCheckingId, setIsCheckingId] = useState(false);
  const [cguAccepted, setCguAccepted] = useState(false);
  const [cvList, setCvList] = useState<CVFile[]>([]);
  const cvFileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (formData.identifiant.length < 3) { setIdError(''); return; }
    setIsCheckingId(true);
    const timer = setTimeout(() => {
      const db = getDB();
      const exists = db.users.some((u: any) => u.identifiant.toLowerCase() === formData.identifiant.toLowerCase());
      setIdError(exists ? 'Identifiant déjà utilisé' : '');
      setIsCheckingId(false);
    }, 400);
    return () => clearTimeout(timer);
  }, [formData.identifiant]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (idError || isCheckingId) return;
    if (!cguAccepted) { alert('Vous devez accepter les CGU et la Politique de confidentialité pour continuer.'); return; }

    const db = getDB();
    if (db.users.some((u: any) => u.email.toLowerCase() === formData.email.toLowerCase() && !initialData)) {
      alert("Email déjà utilisé."); return;
    }

    const newUser: Utilisateur = {
      id: 'u' + Date.now(),
      email: formData.email.toLowerCase(),
      identifiant: formData.identifiant.toLowerCase(),
      password: formData.password || undefined,
      type_utilisateur: role || 'candidat',
      statut_compte: 'actif',
      date_creation: new Date().toISOString(),
      auth_provider: initialData?.auth_provider || 'email',
      social_id: initialData?.social_id || null
    };

    const newProfil: ProfilCandidat = {
      id: 'p' + Date.now(),
      utilisateur_id: newUser.id,
      identifiant: newUser.identifiant,
      nom: formData.nom,
      prenom: formData.prenom,
      date_naissance: formData.date_naissance,
      genre: formData.genre,
      telephone: formData.telephone,
      photo_url: formData.photo_url,
      fiches: [],
      profileViews: 0,
      companyMatches: 0,
      activeRecommendations: 0,
      isProfileVisible: true,
      talentCards: [],
      cvList: cvList,
      cgu_accepted: true,
      cgu_accepted_at: new Date().toISOString(),
      cgu_version: '1.0',
    } as any;

    // PERSISTENCE: Save to real-time mock firestore
    db.users.push(newUser);
    db.profils_candidats.push(newProfil);
    saveDB(db);
    onSignup(newUser, newProfil);
  };

  return (
    <div className="min-h-screen py-12 px-6 max-w-2xl mx-auto">
      <div className="bg-slate-900/70 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl animate-in fade-in duration-500">
        <Logo size="md" className="mb-6 mx-auto" />
        <h2 className="text-3xl font-black text-center mb-2 uppercase italic tracking-tighter">Créer mon profil <BrandText text="Talent" /></h2>
        <p className="text-center text-slate-400 text-[10px] font-black uppercase tracking-widest mb-10">Rejoignez la révolution du recrutement</p>

        <form onSubmit={handleSubmit} className="space-y-8">
          <PhotoUpload currentUrl={formData.photo_url} onPhotoChange={(url) => setFormData({...formData, photo_url: url})} />

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Prénom</label>
                <input type="text" placeholder="Julien" value={formData.prenom} onChange={e => setFormData({...formData, prenom: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold" required />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Nom</label>
                <input type="text" placeholder="Martin" value={formData.nom} onChange={e => setFormData({...formData, nom: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold" required />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Identifiant unique</label>
                <div className="relative">
                  <input type="text" placeholder="jmartin95" value={formData.identifiant} onChange={e => setFormData({...formData, identifiant: e.target.value.replace(/\s/g, '').toLowerCase()})} className={`w-full bg-slate-950 border p-4 rounded-[1.5rem] focus:outline-none font-bold transition-all ${idError ? 'border-red-500' : 'border-white/10 focus:border-orange-500'}`} required />
                  {isCheckingId && <div className="absolute right-4 top-4 animate-spin h-4 w-4 border-2 border-orange-500 border-t-transparent rounded-full"></div>}
                </div>
                {idError && <p className="text-red-500 text-[9px] font-black uppercase mt-1 ml-1">{idError}</p>}
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Date de naissance</label>
                <input type="date" value={formData.date_naissance} onChange={e => setFormData({...formData, date_naissance: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold" required />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Genre</label>
                <select value={formData.genre} onChange={e => setFormData({...formData, genre: e.target.value as Genre})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold">
                  <option value="Homme">Homme</option>
                  <option value="Femme">Femme</option>
                  <option value="Autre">Autre</option>
                  <option value="Préfère ne pas répondre">Préfère ne pas répondre</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Téléphone</label>
                <input type="tel" placeholder="06 12 34 56 78" value={formData.telephone} onChange={e => setFormData({...formData, telephone: e.target.value})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold" required />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 space-y-4">
            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Email</label>
              <input type="email" autoComplete="email" disabled={!!initialData} value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className={`w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold ${initialData ? 'opacity-50 cursor-not-allowed' : 'focus:border-orange-500'}`} required />
            </div>
            {!initialData && (
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Mot de passe</label>
                <PasswordInput value={formData.password} onChange={v => setFormData({...formData, password: v})} autoComplete="new-password" required />
              </div>
            )}
          </div>

          {/* Section CV */}
          <div className="pt-4 border-t border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-black italic uppercase tracking-tighter text-base">Mes CV</h3>
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-1">Ajoutez vos CV (optionnel)</p>
              </div>
              <button
                type="button"
                onClick={() => cvFileRef.current?.click()}
                className="bg-[#FF731D] text-white text-[10px] font-black uppercase px-4 py-2 rounded-2xl hover:bg-orange-500 transition-all"
              >+ Ajouter un CV</button>
            </div>
            <input
              ref={cvFileRef}
              type="file"
              accept=".pdf,.doc,.docx"
              multiple
              className="hidden"
              onChange={e => {
                Array.from(e.target.files || []).forEach(file => {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    setCvList(prev => [...prev, {
                      id: 'cv' + Date.now() + Math.random(),
                      nom: file.name,
                      titre: file.name.replace(/\.[^/.]+$/, ''),
                      base64: reader.result as string,
                      date: new Date().toLocaleDateString('fr-FR')
                    }]);
                  };
                  reader.readAsDataURL(file);
                });
                e.target.value = '';
              }}
            />
            {cvList.length === 0 && (
              <div
                onClick={() => cvFileRef.current?.click()}
                className="border-2 border-dashed border-white/10 rounded-[1.5rem] p-6 text-center cursor-pointer hover:border-orange-500/40 transition-all"
              >
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest">Cliquer pour ajouter un CV (PDF)</p>
              </div>
            )}
            {cvList.map(cv => (
              <div key={cv.id} className="flex items-center gap-3 bg-slate-950 border border-white/10 rounded-[1.5rem] p-4">
                <div className="bg-red-500/20 border border-red-500/30 p-2 rounded-xl shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <input
                    type="text"
                    value={cv.titre}
                    onChange={e => setCvList(prev => prev.map(c => c.id === cv.id ? {...c, titre: e.target.value} : c))}
                    className="w-full bg-transparent text-sm font-bold text-white focus:outline-none border-b border-white/10 focus:border-orange-500 transition-colors pb-1"
                    placeholder="Titre du CV"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">{cv.date}</p>
                </div>
                <button
                  type="button"
                  onClick={() => setCvList(prev => prev.filter(c => c.id !== cv.id))}
                  className="text-slate-500 hover:text-red-400 transition-colors shrink-0 p-1"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-white/10">
            <label className="flex items-start gap-3 cursor-pointer group">
              <input
                type="checkbox"
                checked={cguAccepted}
                onChange={e => setCguAccepted(e.target.checked)}
                className="mt-1 w-4 h-4 accent-orange-500 shrink-0"
                required
              />
              <span className="text-xs text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">
                J'accepte les{' '}
                <button type="button" onClick={() => onShowLegal?.('cgu')} className="text-[#FF731D] underline font-bold hover:text-orange-400 transition-colors">
                  Conditions Générales d'Utilisation
                </button>
                {' '}et la{' '}
                <button type="button" onClick={() => onShowLegal?.('confidentialite')} className="text-[#FF731D] underline font-bold hover:text-orange-400 transition-colors">
                  Politique de confidentialité
                </button>
                {' '}de TalentBook. <span className="text-red-400">*</span>
              </span>
            </label>
          </div>

          <button type="submit" className="w-full bg-[#FF731D] py-5 rounded-[1.5rem] font-black text-xl hover:bg-orange-500 shadow-2xl shadow-orange-950/40 active:scale-95 transition-all uppercase italic">
             Finaliser l'inscription
          </button>
        </form>

        <div className="mt-8 text-center">
          <button onClick={onSwitchToLogin} className="text-slate-400 text-xs font-bold uppercase">Déjà un compte ? Se connecter</button>
        </div>
      </div>
    </div>
  );
};

const fetchMiniScope = () => {
  const db = getDB();
  return {
    secteurs: (db.miniscope_secteurs || []).filter((s: any) => s.actif).map((s: any) => s.nom),
    metiers: (db.miniscope_metiers || []).map((m: any) => {
      const secteur = db.miniscope_secteurs.find((s: any) => s.id === m.secteur_id);
      return {
        ...m,
        secteur: secteur ? secteur.nom : '',
        metier: m.nom_metier
      };
    })
  };
};

const MiniScopeAdminView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [db, setDb] = useState<any>(getDB());
  const [activeTab, setActiveTab] = useState<'secteurs' | 'metiers'>('secteurs');
  
  // Secteur editing state
  const [editingSecteur, setEditingSecteur] = useState<any>(null);
  const [newSecteurName, setNewSecteurName] = useState('');

  // Metier editing state
  const [editingMetier, setEditingMetier] = useState<any>(null);
  const [metierForm, setMetierForm] = useState({
    nom_metier: '',
    secteur_id: '',
    competences_techniques: '',
    soft_skills: '',
    passerelles: ''
  });

  const refreshDB = () => {
    const currentDb = getDB();
    setDb(currentDb);
  };

  const handleSaveSecteur = () => {
    const currentDb = getDB();
    if (editingSecteur) {
      const idx = currentDb.miniscope_secteurs.findIndex((s: any) => s.id === editingSecteur.id);
      if (idx !== -1) {
        currentDb.miniscope_secteurs[idx].nom = newSecteurName;
      }
    } else {
      currentDb.miniscope_secteurs.push({
        id: 's' + Date.now(),
        nom: newSecteurName,
        actif: true
      });
    }
    saveDB(currentDb);
    setEditingSecteur(null);
    setNewSecteurName('');
    refreshDB();
  };

  const handleDeleteSecteur = (id: string) => {
    if (confirm('Supprimer ce secteur ? Cela impactera les métiers liés.')) {
      const currentDb = getDB();
      currentDb.miniscope_secteurs = currentDb.miniscope_secteurs.filter((s: any) => s.id !== id);
      saveDB(currentDb);
      refreshDB();
    }
  };

  const handleSaveMetier = () => {
    const currentDb = getDB();
    const metierData = {
      ...metierForm,
      competences_techniques: metierForm.competences_techniques.split(',').map(s => s.trim()).filter(s => s !== ''),
      soft_skills: metierForm.soft_skills.split(',').map(s => s.trim()).filter(s => s !== ''),
      passerelles: metierForm.passerelles.split(',').map(s => s.trim()).filter(s => s !== '')
    };

    if (editingMetier) {
      const idx = currentDb.miniscope_metiers.findIndex((m: any) => m.id === editingMetier.id);
      if (idx !== -1) {
        currentDb.miniscope_metiers[idx] = { ...editingMetier, ...metierData };
      }
    } else {
      currentDb.miniscope_metiers.push({
        id: 'm' + Date.now(),
        ...metierData
      });
    }
    saveDB(currentDb);
    setEditingMetier(null);
    setMetierForm({ nom_metier: '', secteur_id: '', competences_techniques: '', soft_skills: '', passerelles: '' });
    refreshDB();
  };

  const handleDeleteMetier = (id: string) => {
    if (confirm('Supprimer ce métier ?')) {
      const currentDb = getDB();
      currentDb.miniscope_metiers = currentDb.miniscope_metiers.filter((m: any) => m.id !== id);
      saveDB(currentDb);
      refreshDB();
    }
  };

  return (
    <div className="min-h-screen bg-[#0f172a] p-6 animate-in fade-in duration-500">
      <header className="max-w-6xl mx-auto flex justify-between items-center mb-12">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-3 bg-slate-900 rounded-[1.5rem] border border-white/10 hover:bg-slate-800 transition-all">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h2 className="text-3xl font-black italic uppercase tracking-tighter">Gestion Mini-SCOPE</h2>
        </div>
      </header>

      <main className="max-w-6xl mx-auto space-y-8">
        <div className="flex gap-4 border-b border-white/10 pb-4">
          <button 
            onClick={() => setActiveTab('secteurs')}
            className={`px-6 py-3 rounded-2xl font-black text-xs uppercase transition-all ${activeTab === 'secteurs' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-slate-300'}`}
          >
            Secteurs
          </button>
          <button 
            onClick={() => setActiveTab('metiers')}
            className={`px-6 py-3 rounded-2xl font-black text-xs uppercase transition-all ${activeTab === 'metiers' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-slate-300'}`}
          >
            Métiers & Compétences
          </button>
        </div>

        {activeTab === 'secteurs' && (
          <div className="space-y-6">
            <div className="bg-slate-900/70 p-6 rounded-[2rem] border border-white/10 flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Nom du secteur</label>
                <input 
                  type="text" 
                  value={newSecteurName} 
                  onChange={e => setNewSecteurName(e.target.value)}
                  placeholder="Ex: Agriculture"
                  className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold"
                />
              </div>
              <button 
                onClick={handleSaveSecteur}
                disabled={!newSecteurName}
                className="bg-emerald-600 px-8 py-5 rounded-2xl font-black text-sm uppercase italic hover:bg-emerald-500 transition-all disabled:opacity-50"
              >
                {editingSecteur ? 'Modifier' : 'Ajouter'}
              </button>
              {editingSecteur && (
                <button onClick={() => { setEditingSecteur(null); setNewSecteurName(''); }} className="bg-slate-800 px-8 py-5 rounded-2xl font-black text-sm uppercase italic">Annuler</button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(db.miniscope_secteurs || []).map((s: any) => (
                <div key={s.id} className="bg-slate-900/70 p-6 rounded-[2rem] border border-white/10 flex justify-between items-center group hover:border-emerald-500/30 transition-all">
                  <span className="font-black italic uppercase tracking-tight">{s.nom}</span>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                    <button onClick={() => { setEditingSecteur(s); setNewSecteurName(s.nom); }} className="p-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500 hover:text-white transition-all">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                      </svg>
                    </button>
                    <button onClick={() => handleDeleteSecteur(s.id)} className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500 hover:text-white transition-all">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'metiers' && (
          <div className="space-y-8">
            <div className="bg-slate-900/70 p-8 rounded-[2.5rem] border border-white/10 space-y-6">
              <h3 className="text-xl font-black italic uppercase tracking-tighter text-[#FF731D]">{editingMetier ? 'Modifier le métier' : 'Ajouter un nouveau métier'}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Nom du métier</label>
                  <input 
                    type="text" 
                    value={metierForm.nom_metier} 
                    onChange={e => setMetierForm({...metierForm, nom_metier: e.target.value})}
                    placeholder="Ex: Développeur React"
                    className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Secteur associé</label>
                  <select 
                    value={metierForm.secteur_id} 
                    onChange={e => setMetierForm({...metierForm, secteur_id: e.target.value})}
                    className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold"
                  >
                    <option value="">Choisir un secteur</option>
                    {(db.miniscope_secteurs || []).map((s: any) => (
                      <option key={s.id} value={s.id}>{s.nom}</option>
                    ))}
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Compétences techniques (séparées par des virgules)</label>
                  <textarea 
                    value={metierForm.competences_techniques} 
                    onChange={e => setMetierForm({...metierForm, competences_techniques: e.target.value})}
                    placeholder="React, TypeScript, Tailwind..."
                    className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold h-24"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Soft Skills (séparées par des virgules)</label>
                  <textarea 
                    value={metierForm.soft_skills} 
                    onChange={e => setMetierForm({...metierForm, soft_skills: e.target.value})}
                    placeholder="Autonomie, Rigueur, Communication..."
                    className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold h-24"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Passerelles métiers (séparées par des virgules)</label>
                  <textarea 
                    value={metierForm.passerelles} 
                    onChange={e => setMetierForm({...metierForm, passerelles: e.target.value})}
                    placeholder="Vendeur conseil, Adjoint chef de rayon..."
                    className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold h-24"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={handleSaveMetier}
                  disabled={!metierForm.nom_metier || !metierForm.secteur_id}
                  className="flex-1 bg-emerald-600 py-5 rounded-[1.5rem] font-black text-lg uppercase italic hover:bg-emerald-500 transition-all disabled:opacity-50"
                >
                  {editingMetier ? 'Mettre à jour' : 'Enregistrer le métier'}
                </button>
                {editingMetier && (
                  <button onClick={() => { setEditingMetier(null); setMetierForm({ nom_metier: '', secteur_id: '', competences_techniques: '', soft_skills: '', passerelles: '' }); }} className="bg-slate-800 px-10 py-5 rounded-[1.5rem] font-black text-lg uppercase italic">Annuler</button>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-xl font-black italic uppercase tracking-tighter px-4">Liste des métiers</h3>
              <div className="grid grid-cols-1 gap-4">
                {(db.miniscope_metiers || []).map((m: any) => {
                  const secteur = db.miniscope_secteurs.find((s: any) => s.id === m.secteur_id);
                  return (
                    <div key={m.id} className="bg-slate-900/70 p-6 rounded-[2.5rem] border border-white/10 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 group hover:border-emerald-500/30 transition-all">
                      <div className="space-y-1">
                        <div className="flex items-center gap-3">
                          <span className="font-black italic uppercase tracking-tight text-lg">{m.nom_metier}</span>
                          <span className="bg-emerald-500/10 text-emerald-500 text-[8px] font-black uppercase px-2 py-1 rounded border border-emerald-500/20">{secteur?.nom || 'Sans secteur'}</span>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {m.competences_techniques.slice(0, 3).map((c: string, i: number) => (
                            <span key={i} className="text-[8px] font-bold text-slate-400 uppercase">{c}</span>
                          ))}
                          {m.competences_techniques.length > 3 && <span className="text-[8px] font-bold text-slate-400 uppercase">+{m.competences_techniques.length - 3}</span>}
                        </div>
                        {m.passerelles && m.passerelles.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            <span className="text-[7px] font-black text-purple-500 uppercase mr-1">Passerelles:</span>
                            {m.passerelles.slice(0, 2).map((p: string, i: number) => (
                              <span key={i} className="text-[7px] font-bold text-slate-400 uppercase">{p}</span>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                        <button 
                          onClick={() => { 
                            setEditingMetier(m); 
                            setMetierForm({
                              nom_metier: m.nom_metier,
                              secteur_id: m.secteur_id,
                              competences_techniques: m.competences_techniques.join(', '),
                              soft_skills: m.soft_skills.join(', '),
                              passerelles: (m.passerelles || []).join(', ')
                            });
                          }} 
                          className="p-3 bg-blue-500/20 text-blue-400 rounded-2xl hover:bg-blue-500 hover:text-white transition-all"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                          </svg>
                        </button>
                        <button onClick={() => handleDeleteMetier(m.id)} className="p-3 bg-red-500/20 text-red-400 rounded-2xl hover:bg-red-500 hover:text-white transition-all">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const TalentCardView: React.FC<{ profil: ProfilCandidat, onSave: (card: TalentCard) => void, onCancel: () => void }> = ({ profil, onSave, onCancel }) => {
  const [card, setCard] = useState({
    titre: '',
    experience: '',
    disponibilite: 'Immédiate',
    type_contrat: 'CDI',
    ville: '',
    code_postal: '',
    niveau: 'Débutant' as 'Débutant' | 'Confirmé' | 'Expert',
    rayon_mobilite: '30',
    cdd_date_debut: '',
    cdd_date_fin: '',
    alternance_date_debut: '',
  });

  const [selectedSector, setSelectedSector] = useState('');
  const [selectedMetier, setSelectedMetier] = useState('');
  const [selectedCompetences, setSelectedCompetences] = useState<string[]>([]);
  const [selectedSoftSkills, setSelectedSoftSkills] = useState<string[]>([]);
  const [cvList, setCvList] = useState<{ id: string; nom: string; base64: string; date: string }[]>(profil.cvList || []);
  const [selectedCvIds, setSelectedCvIds] = useState<string[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analyzeMsg, setAnalyzeMsg] = useState('');

  const miniScope = fetchMiniScope();
  const metiersForSector = miniScope.metiers.filter(m => m.secteur === selectedSector);
  const currentMetierData = miniScope.metiers.find(m => m.metier === selectedMetier);

  useEffect(() => {
    setSelectedMetier('');
    setSelectedCompetences([]);
    setSelectedSoftSkills([]);
  }, [selectedSector]);

  useEffect(() => {
    if (currentMetierData) {
      setSelectedCompetences([...currentMetierData.competences_techniques]);
      setSelectedSoftSkills([...currentMetierData.soft_skills]);
    } else {
      setSelectedCompetences([]);
      setSelectedSoftSkills([]);
    }
  }, [selectedMetier]);

  const handleAnalyzeCV = async (base64: string, nom: string) => {
    setIsAnalyzing(true);
    setAnalyzeMsg(`Analyse de "${nom}" en cours...`);
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: [
              {
                type: 'document',
                source: { type: 'base64', media_type: 'application/pdf', data: base64.split(',')[1] || base64 }
              },
              {
                type: 'text',
                text: `Analyse ce CV et extrais les informations suivantes en JSON strict (sans markdown) :
{
  "titre": "titre du poste principal",
  "experience": "nombre d'années d'expérience (ex: 3 ans)",
  "competences": ["compétence1", "compétence2", ...],
  "softSkills": ["soft skill1", "soft skill2", ...],
  "ville": "ville principale",
  "code_postal": "code postal si trouvé sinon vide",
  "secteur": "secteur d'activité"
}`
              }
            ]
          }]
        })
      });
      const data = await response.json();
      const text = data.content?.[0]?.text || '';
      try {
        const clean = text.replace(/```json|```/g, '').trim();
        const parsed = JSON.parse(clean);
        // Pré-remplir le formulaire avec les données extraites
        if (parsed.titre) setCard(c => ({...c, titre: parsed.titre}));
        if (parsed.experience) setCard(c => ({...c, experience: parsed.experience}));
        if (parsed.ville) setCard(c => ({...c, ville: parsed.ville}));
        if (parsed.code_postal) setCard(c => ({...c, code_postal: parsed.code_postal}));
        if (parsed.competences?.length) setSelectedCompetences(parsed.competences);
        if (parsed.softSkills?.length) setSelectedSoftSkills(parsed.softSkills);
        if (parsed.secteur) {
          const matchSecteur = miniScope.secteurs.find(s => s.toLowerCase().includes(parsed.secteur.toLowerCase()));
          if (matchSecteur) setSelectedSector(matchSecteur);
        }
        setAnalyzeMsg('✓ CV analysé — formulaire pré-rempli !');
      } catch {
        setAnalyzeMsg('CV analysé mais format inattendu. Vérifiez les champs.');
      }
    } catch {
      setAnalyzeMsg('Erreur lors de l\'analyse. Vérifiez votre connexion.');
    }
    setIsAnalyzing(false);
    setTimeout(() => setAnalyzeMsg(''), 4000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let disponibiliteLabel = card.disponibilite;
    if (card.type_contrat === 'CDD' && card.cdd_date_debut && card.cdd_date_fin) {
      disponibiliteLabel = `CDD du ${card.cdd_date_debut} au ${card.cdd_date_fin}`;
    } else if (card.type_contrat === 'Alternance' && card.alternance_date_debut) {
      disponibiliteLabel = `Alternance dès le ${card.alternance_date_debut}`;
    }

    const newCard: TalentCard = {
      id: 'tc' + Date.now(),
      titre: card.titre,
      secteur: selectedSector,
      metier: selectedMetier,
      competences: selectedCompetences,
      softSkills: selectedSoftSkills,
      experience: card.experience,
      disponibilite: disponibiliteLabel,
      ville: card.ville,
      code_postal: card.code_postal,
      type_contrat: card.type_contrat,
      niveau: card.niveau,
      rayon_mobilite: card.rayon_mobilite,
      cv_ids: selectedCvIds,
    };
    onSave(newCard);
  };

  const toggleCompetence = (comp: string) => {
    setSelectedCompetences(prev => prev.includes(comp) ? prev.filter(c => c !== comp) : [...prev, comp]);
  };
  const toggleSoftSkill = (skill: string) => {
    setSelectedSoftSkills(prev => prev.includes(skill) ? prev.filter(s => s !== skill) : [...prev, skill]);
  };

  const inputCls = "w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-orange-500 transition-all font-bold";

  return (
    <div className="min-h-screen bg-[#0f172a] p-6 animate-in slide-in-from-bottom-10 duration-500">
      <div className="max-w-2xl mx-auto bg-slate-900/70 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl">
        <Logo size="sm" className="mb-8" />
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">Créer une Talent Card</h2>
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-8">Présentez vos atouts aux recruteurs</p>

        {/* Section CV — sélection depuis les CV du profil */}
        <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10 mb-6 space-y-4">
          <h3 className="text-xs font-black uppercase tracking-widest text-orange-500">CV associé</h3>
          {(profil.cvList || []).length === 0 ? (
            <p className="text-slate-500 text-xs font-bold italic">Aucun CV dans votre profil. Ajoutez-en un depuis la page de modification de profil.</p>
          ) : (
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-2">Sélectionnez le CV correspondant à cette carte</label>
              {(profil.cvList || []).map((cv: any) => (
                <label key={cv.id} className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${selectedCvIds.includes(cv.id) ? 'bg-orange-500/10 border-orange-500/50' : 'bg-slate-950 border-white/10 hover:border-white/20'}`}>
                  <input type="checkbox" className="hidden" checked={selectedCvIds.includes(cv.id)} onChange={() => setSelectedCvIds(prev => prev.includes(cv.id) ? prev.filter(id => id !== cv.id) : [...prev, cv.id])} />
                  <div className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${selectedCvIds.includes(cv.id) ? 'bg-orange-500 border-orange-500' : 'border-slate-700'}`}>
                    {selectedCvIds.includes(cv.id) && <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-black text-white truncate">{cv.titre || cv.nom}</p>
                    <p className="text-[10px] text-slate-500 truncate">{cv.nom}</p>
                  </div>
                  {selectedCvIds.includes(cv.id) && (
                    <button
                      type="button"
                      onClick={() => {
                        const cvData = cv.base64;
                        if (cvData) handleAnalyzeCV(cvData, cv.nom);
                      }}
                      disabled={isAnalyzing}
                      className="ml-auto bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 text-[9px] font-black uppercase px-3 py-1.5 rounded-xl hover:bg-emerald-600/30 transition-all disabled:opacity-50 shrink-0"
                    >
                      {isAnalyzing ? '...' : 'Analyser IA'}
                    </button>
                  )}
                </label>
              ))}
              {analyzeMsg && (
                <div className={`text-xs font-bold px-4 py-3 rounded-2xl animate-in fade-in duration-300 ${analyzeMsg.startsWith('✓') ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-orange-500/10 border border-orange-500/30 text-orange-400'}`}>
                  {analyzeMsg}
                </div>
              )}
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">

          {/* Titre */}
          <div>
            <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Titre de la carte</label>
            <input type="text" placeholder="Ex: Développeur Fullstack Passionné" value={card.titre} onChange={e => setCard({...card, titre: e.target.value})} className={inputCls} required />
          </div>

          {/* Secteur / Métier */}
          <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10 space-y-4">
            <h3 className="text-xs font-black uppercase tracking-widest text-orange-500">Métier</h3>
            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Secteur</label>
              <select value={selectedSector} onChange={e => setSelectedSector(e.target.value)} className={inputCls} required>
                <option value="">Sélectionnez un secteur</option>
                {miniScope.secteurs.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Métier</label>
              <select value={selectedMetier} onChange={e => setSelectedMetier(e.target.value)} disabled={!selectedSector} className={`${inputCls} disabled:opacity-30`} required>
                <option value="">Sélectionnez un métier</option>
                {metiersForSector.map(m => <option key={m.id} value={m.metier}>{m.metier}</option>)}
              </select>
            </div>
            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Niveau d'expertise</label>
              <select value={card.niveau} onChange={e => setCard({...card, niveau: e.target.value as any})} className={inputCls}>
                <option value="Débutant">Débutant</option>
                <option value="Confirmé">Confirmé</option>
                <option value="Expert">Expert</option>
              </select>
            </div>
          </div>

          {/* Compétences + Soft Skills */}
          {selectedMetier && currentMetierData && (
            <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-emerald-500">Compétences techniques</h3>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setSelectedCompetences([...currentMetierData.competences_techniques])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white transition-colors">Tout sélectionner</button>
                    <button type="button" onClick={() => setSelectedCompetences([])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white transition-colors">Tout désélectionner</button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {currentMetierData.competences_techniques.map(comp => (
                    <label key={comp} className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${selectedCompetences.includes(comp) ? 'bg-emerald-500/10 border-emerald-500/50' : 'bg-slate-950 border-white/10 hover:border-white/20'}`}>
                      <input type="checkbox" className="hidden" checked={selectedCompetences.includes(comp)} onChange={() => toggleCompetence(comp)} />
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${selectedCompetences.includes(comp) ? 'bg-emerald-500 border-emerald-500' : 'border-slate-700'}`}>
                        {selectedCompetences.includes(comp) && <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                      </div>
                      <span className="text-xs font-bold">{comp}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-blue-500">Soft Skills</h3>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setSelectedSoftSkills([...currentMetierData.soft_skills])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white transition-colors">Tout sélectionner</button>
                    <button type="button" onClick={() => setSelectedSoftSkills([])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white transition-colors">Tout désélectionner</button>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {currentMetierData.soft_skills.map(skill => (
                    <label key={skill} className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${selectedSoftSkills.includes(skill) ? 'bg-blue-500/10 border-blue-500/50' : 'bg-slate-950 border-white/10 hover:border-white/20'}`}>
                      <input type="checkbox" className="hidden" checked={selectedSoftSkills.includes(skill)} onChange={() => toggleSoftSkill(skill)} />
                      <div className={`w-4 h-4 rounded border flex items-center justify-center transition-all ${selectedSoftSkills.includes(skill) ? 'bg-blue-500 border-blue-500' : 'border-slate-700'}`}>
                        {selectedSoftSkills.includes(skill) && <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>}
                      </div>
                      <span className="text-xs font-bold">{skill}</span>
                    </label>
                  ))}
                </div>
              </div>

              {currentMetierData.passerelles && currentMetierData.passerelles.length > 0 && (
                <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                  <h3 className="text-xs font-black uppercase tracking-widest text-purple-400 mb-4">Passerelles métiers possibles</h3>
                  <div className="flex flex-wrap gap-2">
                    {currentMetierData.passerelles.map(pass => (
                      <span key={pass} className="bg-purple-500/10 border border-purple-500/30 px-3 py-1 rounded-lg text-[10px] font-black uppercase text-purple-300">{pass}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Localisation + Contrat */}
          <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10 space-y-4">
            <h3 className="text-xs font-black uppercase tracking-widest text-orange-500">Contrat & Localisation</h3>

            <CodePostalSelect
              cp={card.code_postal}
              ville={card.ville}
              onCPChange={cp => setCard(prev => ({...prev, code_postal: cp, ville: ''}))}
              onVilleChange={ville => setCard(prev => ({...prev, ville}))}
            />

            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Rayon de mobilité</label>
              <select value={card.rayon_mobilite} onChange={e => setCard({...card, rayon_mobilite: e.target.value})} className={inputCls}>
                <option value="10">10 km</option>
                <option value="30">30 km</option>
                <option value="50">50 km</option>
                <option value="100">100 km</option>
                <option value="france">Toute la France</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Type de contrat</label>
              <select value={card.type_contrat} onChange={e => setCard({...card, type_contrat: e.target.value})} className={inputCls}>
                <option value="CDI">CDI</option>
                <option value="CDD">CDD</option>
                <option value="Alternance">Alternance</option>
              </select>
            </div>

            {/* Dates conditionnelles CDD */}
            {card.type_contrat === 'CDD' && (
              <div className="grid grid-cols-2 gap-4 animate-in fade-in slide-in-from-top-2 duration-300">
                <div>
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Date de début</label>
                  <input type="date" value={card.cdd_date_debut} onChange={e => setCard({...card, cdd_date_debut: e.target.value})} className={inputCls} required />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Date de fin</label>
                  <input type="date" value={card.cdd_date_fin} onChange={e => setCard({...card, cdd_date_fin: e.target.value})} className={inputCls} required />
                </div>
              </div>
            )}

            {/* Date de début Alternance */}
            {card.type_contrat === 'Alternance' && (
              <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Date de début de l'alternance</label>
                <input type="date" value={card.alternance_date_debut} onChange={e => setCard({...card, alternance_date_debut: e.target.value})} className={inputCls} required />
              </div>
            )}
          </div>

          {/* Expérience + Disponibilité (CDI seulement) */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Expérience</label>
              <input type="text" placeholder="Ex: 5 ans" value={card.experience} onChange={e => setCard({...card, experience: e.target.value})} className={inputCls} />
            </div>
            {card.type_contrat === 'CDI' && (
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Disponibilité</label>
                <select value={card.disponibilite} onChange={e => setCard({...card, disponibilite: e.target.value})} className={inputCls}>
                  <option value="Immédiate">Immédiate</option>
                  <option value="1 mois">1 mois</option>
                  <option value="3 mois">3 mois</option>
                </select>
              </div>
            )}
          </div>

          <div className="flex gap-4 pt-4">
            <button type="submit" className="flex-1 bg-[#FF731D] py-5 rounded-[1.5rem] font-black text-lg hover:bg-orange-500 transition-all uppercase italic">Enregistrer</button>
            <button type="button" onClick={onCancel} className="flex-1 bg-slate-800 py-5 rounded-[1.5rem] font-black text-lg hover:bg-slate-700 transition-all uppercase italic">Annuler</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const CandidateFicheView: React.FC<{ profil: ProfilCandidat, onSave: (fiche: FicheCandidat) => void, onCancel: () => void }> = ({ profil, onSave, onCancel }) => {
  const [selectedSector, setSelectedSector] = useState('');
  const [selectedMetier, setSelectedMetier] = useState('');
  const [selectedCompetences, setSelectedCompetences] = useState<string[]>([]);
  const [selectedSoftSkills, setSelectedSoftSkills] = useState<string[]>([]);
  const [niveau, setNiveau] = useState<'Débutant' | 'Confirmé' | 'Expert'>('Débutant');
  const [ficheData, setFicheData] = useState({
    ville: '',
    code_postal: '',
    type_contrat: 'CDI' as any,
    disponibilite: 'immediate' as any,
    enseigne_preferee: ''
  });

  const miniScope = fetchMiniScope();
  const metiersForSector = miniScope.metiers.filter(m => m.secteur === selectedSector);
  const currentMetierData = miniScope.metiers.find(m => m.metier === selectedMetier);

  useEffect(() => {
    setSelectedMetier('');
    setSelectedCompetences([]);
    setSelectedSoftSkills([]);
  }, [selectedSector]);

  useEffect(() => {
    if (currentMetierData) {
      setSelectedCompetences([...currentMetierData.competences_techniques]);
      setSelectedSoftSkills([...currentMetierData.soft_skills]);
    }
  }, [selectedMetier]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newFiche: FicheCandidat = {
      id: 'f' + Date.now(),
      profil_candidat_id: profil.id,
      secteur: selectedSector,
      metier: selectedMetier,
      niveau: niveau,
      competences_techniques: selectedCompetences,
      soft_skills: selectedSoftSkills,
      passerelles: currentMetierData?.passerelles || [],
      enseigne_preferee: ficheData.enseigne_preferee,
      disponibilite: ficheData.disponibilite,
      type_contrat: ficheData.type_contrat,
      ville: ficheData.ville,
      code_postal: ficheData.code_postal,
      rayon_mobilite: 30,
      logiciels: [],
      est_actif: true,
      date_creation: new Date().toISOString()
    };
    onSave(newFiche);
  };

  const toggleCompetence = (comp: string) => {
    setSelectedCompetences(prev => prev.includes(comp) ? prev.filter(c => c !== comp) : [...prev, comp]);
  };

  const toggleSoftSkill = (skill: string) => {
    setSelectedSoftSkills(prev => prev.includes(skill) ? prev.filter(s => s !== skill) : [...prev, skill]);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] p-6 animate-in slide-in-from-bottom-10 duration-500">
      <div className="max-w-3xl mx-auto bg-slate-900/70 backdrop-blur-xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl">
        <Logo size="sm" className="mb-8" />
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">Référentiel Métier</h2>
        <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-8">Configurez votre fiche professionnelle Mini-SCOPE</p>
        
        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Secteur</label>
                <select value={selectedSector} onChange={e => setSelectedSector(e.target.value)} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold" required>
                  <option value="">Sélectionnez un secteur</option>
                  {miniScope.secteurs.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Métier</label>
                <select value={selectedMetier} onChange={e => setSelectedMetier(e.target.value)} disabled={!selectedSector} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold disabled:opacity-30" required>
                  <option value="">Sélectionnez un métier</option>
                  {metiersForSector.map(m => <option key={m.id} value={m.metier}>{m.metier}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Niveau d'expertise</label>
                <select value={niveau} onChange={e => setNiveau(e.target.value as any)} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold">
                  <option value="Débutant">Débutant</option>
                  <option value="Confirmé">Confirmé</option>
                  <option value="Expert">Expert</option>
                </select>
              </div>
            </div>

            <div className="space-y-4">
              <CodePostalSelect
                cp={ficheData.code_postal}
                ville={ficheData.ville}
                onCPChange={cp => setFicheData(prev => ({...prev, code_postal: cp, ville: ''}))}
                onVilleChange={ville => setFicheData(prev => ({...prev, ville}))}
                accentColor="emerald"
                required
              />
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Contrat</label>
                <select value={ficheData.type_contrat} onChange={e => setFicheData({...ficheData, type_contrat: e.target.value as any})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold">
                  <option value="CDI">CDI</option>
                  <option value="CDD">CDD</option>
                  <option value="Alternance">Alternance</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 ml-1">Disponibilité</label>
                <select value={ficheData.disponibilite} onChange={e => setFicheData({...ficheData, disponibilite: e.target.value as any})} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] focus:border-emerald-500 transition-all font-bold">
                  <option value="immediate">Immédiate</option>
                  <option value="1 mois">1 mois</option>
                  <option value="> 1 mois">{'>'} 1 mois</option>
                </select>
              </div>
            </div>
          </div>

          {selectedMetier && currentMetierData && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-emerald-500">Compétences techniques</h3>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setSelectedCompetences([...currentMetierData.competences_techniques])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white">Tout sélectionner</button>
                    <button type="button" onClick={() => setSelectedCompetences([])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white">Tout désélectionner</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {currentMetierData.competences_techniques.map(comp => (
                    <label key={comp} className={`flex items-center gap-2 p-3 rounded-2xl border transition-all cursor-pointer ${selectedCompetences.includes(comp) ? 'bg-emerald-500/10 border-emerald-500/50' : 'bg-slate-950 border-white/10'}`}>
                      <input type="checkbox" className="hidden" checked={selectedCompetences.includes(comp)} onChange={() => toggleCompetence(comp)} />
                      <span className={`text-[10px] font-bold ${selectedCompetences.includes(comp) ? 'text-white' : 'text-slate-400'}`}>{comp}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-blue-400">Soft Skills</h3>
                  <div className="flex gap-2">
                    <button type="button" onClick={() => setSelectedSoftSkills([...currentMetierData.soft_skills])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white">Tout sélectionner</button>
                    <button type="button" onClick={() => setSelectedSoftSkills([])} className="text-[9px] font-black uppercase text-slate-400 hover:text-white">Tout désélectionner</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {currentMetierData.soft_skills.map(skill => (
                    <label key={skill} className={`flex items-center gap-2 p-3 rounded-2xl border transition-all cursor-pointer ${selectedSoftSkills.includes(skill) ? 'bg-blue-500/10 border-blue-500/50' : 'bg-slate-950 border-white/10'}`}>
                      <input type="checkbox" className="hidden" checked={selectedSoftSkills.includes(skill)} onChange={() => toggleSoftSkill(skill)} />
                      <span className={`text-[10px] font-bold ${selectedSoftSkills.includes(skill) ? 'text-white' : 'text-slate-400'}`}>{skill}</span>
                    </label>
                  ))}
                </div>
              </div>

              {currentMetierData.passerelles && currentMetierData.passerelles.length > 0 && (
                <div className="bg-slate-800/60 p-6 rounded-[2rem] border border-white/10">
                  <h3 className="text-xs font-black uppercase tracking-widest text-purple-400 mb-4">Passerelles métiers possibles</h3>
                  <div className="flex flex-wrap gap-2">
                    {currentMetierData.passerelles.map(pass => (
                      <span key={pass} className="bg-purple-500/10 border border-purple-500/30 px-3 py-1 rounded-lg text-[10px] font-black uppercase text-purple-300">{pass}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex gap-4 pt-6">
            <button type="submit" className="flex-1 bg-emerald-600 py-5 rounded-[1.5rem] font-black text-lg uppercase italic hover:bg-emerald-500 transition-all shadow-xl shadow-emerald-950/20">Enregistrer la fiche</button>
            <button type="button" onClick={onCancel} className="bg-slate-800 px-10 py-5 rounded-[1.5rem] font-black text-lg uppercase italic">Annuler</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const CompanyDashboard: React.FC<{ profil: ProfilEntreprise, onLogout: () => void }> = ({ profil, onLogout }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSector, setSelectedSector] = useState('');
  const [selectedMetier, setSelectedMetier] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showContrat, setShowContrat] = useState(() => {
    // Afficher la modale si l'entreprise n'a pas encore accepté le contrat
    try {
      const db = getDB();
      const p = db.profils_entreprises.find((pe: any) => pe.id === profil.id);
      return !p?.contract_accepted;
    } catch { return true; }
  });

  const miniScope = fetchMiniScope();
  const metiersForSector = miniScope.metiers.filter(m => m.secteur === selectedSector);

  const handleSearch = () => {
    setIsSearching(true);
    setTimeout(() => {
      const db = getDB();
      const allTalents: any[] = [];
      db.profils_candidats.forEach((p: any) => {
        if (!p.isProfileVisible) return;
        
        // Search in Talent Cards
        p.talentCards.forEach((card: any) => {
          let score = 0;
          if (selectedSector && card.secteur === selectedSector) score += 50;
          if (selectedMetier && card.metier === selectedMetier) score += 100;
          
          if (score > 0 || (!selectedSector && !selectedMetier)) {
            allTalents.push({
              id: p.id,
              prenom: p.prenom,
              nom: p.nom,
              photo_url: p.photo_url,
              identifiant: p.identifiant,
              type: 'Talent Card',
              titre: card.titre,
              metier: card.metier,
              secteur: card.secteur,
              score: score
            });
          }
        });

        // Search in Fiches
        (p.fiches || []).forEach((fiche: any) => {
          let score = 0;
          if (selectedSector && fiche.secteur === selectedSector) score += 50;
          if (selectedMetier && fiche.metier === selectedMetier) score += 100;

          if (score > 0) {
            allTalents.push({
              id: p.id,
              prenom: p.prenom,
              nom: p.nom,
              photo_url: p.photo_url,
              identifiant: p.identifiant,
              type: 'Fiche Métier',
              titre: fiche.metier,
              metier: fiche.metier,
              secteur: fiche.secteur,
              score: score + 10 // Bonus for structured fiche
            });
          }
        });
      });

      // Remove duplicates (same candidate, multiple matches) - keep highest score
      const uniqueTalents = allTalents.reduce((acc: any[], current) => {
        const x = acc.find(item => item.id === current.id);
        if (!x) return acc.concat([current]);
        if (current.score > x.score) {
          return acc.map(item => item.id === current.id ? current : item);
        }
        return acc;
      }, []);

      setResults(uniqueTalents.sort((a, b) => b.score - a.score));
      setIsSearching(false);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#0f172a] pb-24 animate-in fade-in duration-500">
      {showContrat && (
        <ContratB2BModal
          onAccept={() => {
            const db = getDB();
            const idx = db.profils_entreprises.findIndex((pe: any) => pe.id === profil.id);
            if (idx !== -1) {
              db.profils_entreprises[idx].contract_accepted = true;
              db.profils_entreprises[idx].contract_accepted_at = new Date().toISOString();
              db.profils_entreprises[idx].contract_version = '1.0';
              db.profils_entreprises[idx].contract_signed_by = profil.utilisateur_id;
              saveDB(db);
            }
            setShowContrat(false);
          }}
          onDecline={onLogout}
        />
      )}
      <header className="p-6 border-b border-white/10 flex justify-between items-center bg-slate-900/70 backdrop-blur-xl sticky top-0 z-50">
        <Logo size="sm" />
        <div className="flex items-center gap-6">
          <div className="hidden md:block text-right">
            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Entreprise</p>
            <p className="text-xs font-bold text-white uppercase italic">{profil.nom_entreprise}</p>
          </div>
          <button onClick={onLogout} className="text-red-500 text-[10px] font-black uppercase tracking-widest hover:text-red-400 transition-colors">Déconnexion</button>
        </div>
      </header>

      <main className="p-6 max-w-6xl mx-auto space-y-12 mt-6">
        <section className="text-center space-y-4">
          <h2 className="text-4xl md:text-6xl font-black italic uppercase tracking-tighter leading-none">
            Trouvez vos futurs <BrandText text="Talents" />
          </h2>
          <p className="text-slate-400 text-xs md:text-sm font-bold uppercase tracking-[0.2em]">Moteur de recherche prédictif basé sur le Mini-SCOPE</p>
        </section>

        <section className="bg-slate-900/70 p-8 rounded-[2.5rem] border border-white/10 shadow-2xl space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Secteur d'activité</label>
              <select value={selectedSector} onChange={e => setSelectedSector(e.target.value)} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold focus:border-[#FF731D] transition-all">
                <option value="">Tous les secteurs</option>
                {miniScope.secteurs.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Métier recherché</label>
              <select value={selectedMetier} onChange={e => setSelectedMetier(e.target.value)} disabled={!selectedSector} className="w-full bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold focus:border-[#FF731D] transition-all disabled:opacity-30">
                <option value="">Tous les métiers</option>
                {metiersForSector.map(m => <option key={m.id} value={m.metier}>{m.metier}</option>)}
              </select>
            </div>
            <div className="flex items-end">
              <button onClick={handleSearch} className="w-full bg-[#FF731D] py-5 rounded-2xl font-black text-lg uppercase italic hover:scale-[1.02] active:scale-95 transition-all shadow-xl shadow-orange-950/20">
                {isSearching ? 'Recherche...' : 'Lancer le Match ➔'}
              </button>
            </div>
          </div>
        </section>

        <section className="space-y-6">
          <div className="flex justify-between items-center px-4">
            <h3 className="font-black italic uppercase tracking-tighter text-2xl">Résultats du Match</h3>
            <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{results.length} Talents trouvés</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {results.map((talent, idx) => (
              <div key={idx} className="bg-slate-900/70 p-6 rounded-[2.5rem] border border-white/10 hover:border-[#FF731D]/30 transition-all group relative overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${idx * 50}ms` }}>
                {/* Bouton supprimer ce résultat */}
                <button
                  onClick={() => setResults(prev => prev.filter((_, i) => i !== idx))}
                  className="absolute top-4 right-4 text-slate-600 hover:text-red-400 transition-colors p-1 z-10"
                  title="Retirer ce résultat"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-full border-2 border-[#FF731D] overflow-hidden shrink-0">
                    {talent.photo_url ? <img src={talent.photo_url} alt="" className="w-full h-full object-cover" /> : <div className="w-full h-full bg-slate-800 flex items-center justify-center font-black italic">{talent.prenom[0]}</div>}
                  </div>
                  <div>
                    <h4 className="font-black italic uppercase tracking-tight text-lg leading-tight">{talent.prenom} {talent.nom[0]}.</h4>
                    <p className="text-[#FF731D] text-[10px] font-black uppercase tracking-widest">@{talent.identifiant}</p>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="bg-white/5 p-4 rounded-[1.5rem] border border-white/10">
                    <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-1">{talent.type}</p>
                    <p className="font-bold text-sm text-white italic">{talent.titre}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="bg-emerald-500/10 text-emerald-500 text-[8px] font-black uppercase px-2 py-1 rounded border border-emerald-500/20">{talent.metier}</span>
                    <button className="text-[10px] font-black uppercase text-[#FF731D] hover:underline">Voir Profil ➔</button>
                  </div>
                </div>
              </div>
            ))}
            {results.length === 0 && !isSearching && (
              <div className="col-span-full py-20 text-center space-y-4">
                <div className="text-slate-700 text-6xl font-black italic uppercase opacity-20">Aucun Match</div>
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Ajustez vos critères pour trouver des talents</p>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

// Gestionnaire de CV réutilisable (édition profil + signup)
const CVManagerInline: React.FC<{
  cvList: CVFile[];
  onChange: (list: CVFile[]) => void;
}> = ({ cvList, onChange }) => {
  const fileRef = useRef<HTMLInputElement>(null);

  const handleAdd = (e: React.ChangeEvent<HTMLInputElement>) => {
    Array.from(e.target.files || []).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        onChange([...cvList, {
          id: 'cv' + Date.now() + Math.random(),
          nom: file.name,
          titre: file.name.replace(/\.[^/.]+$/, ''),
          base64: reader.result as string,
          date: new Date().toLocaleDateString('fr-FR')
        }]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="font-black italic uppercase tracking-tighter text-sm">Mes CV</h4>
          <p className="text-slate-400 text-[9px] font-bold uppercase tracking-widest mt-0.5">{cvList.length} fichier{cvList.length > 1 ? 's' : ''}</p>
        </div>
        <button type="button" onClick={() => fileRef.current?.click()} className="bg-[#FF731D] text-white text-[9px] font-black uppercase px-3 py-2 rounded-2xl hover:bg-orange-500 transition-all">
          + Ajouter
        </button>
      </div>
      <input ref={fileRef} type="file" accept=".pdf,.doc,.docx" multiple className="hidden" onChange={handleAdd} />
      {cvList.length === 0 && (
        <div onClick={() => fileRef.current?.click()} className="border-2 border-dashed border-white/10 rounded-[1.5rem] p-5 text-center cursor-pointer hover:border-orange-500/40 transition-all">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">Cliquer pour ajouter un CV</p>
        </div>
      )}
      {cvList.map(cv => (
        <div key={cv.id} className="flex items-center gap-3 bg-slate-950 border border-white/10 rounded-[1.5rem] p-3">
          <div className="bg-red-500/20 border border-red-500/30 p-2 rounded-xl shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <input
              type="text"
              value={(cv as any).titre || cv.nom}
              onChange={e => onChange(cvList.map(c => c.id === cv.id ? {...c, titre: e.target.value} : c))}
              className="w-full bg-transparent text-sm font-bold text-white focus:outline-none border-b border-white/10 focus:border-orange-500 transition-colors pb-1"
              placeholder="Titre du CV"
            />
            <p className="text-[9px] text-slate-500 mt-1 truncate">{cv.nom} · {cv.date}</p>
          </div>
          <button type="button" onClick={() => onChange(cvList.filter(c => c.id !== cv.id))} className="text-slate-500 hover:text-red-400 transition-colors shrink-0 p-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
};

const CandidateDashboard: React.FC<{ user: Utilisateur | null, profil: any, onLogout: () => void, onUpdateProfile: (newProfil: any) => void, onCreateCard: () => void, setSubView: (v: string) => void }> = ({ user, profil, onLogout, onUpdateProfile, onCreateCard, setSubView }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localSubView, setLocalSubView] = useState<'main' | 'contacts'>('main');
  const [editedData, setEditedData] = useState({ ...profil });

  const handleSave = () => {
    onUpdateProfile(editedData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedData({ ...profil });
    setIsEditing(false);
  };

  const toggleVisibility = () => {
    const updated = { ...profil, isProfileVisible: !profil.isProfileVisible };
    onUpdateProfile(updated);
    setEditedData(updated);
  };

  if (localSubView === 'contacts') {
    const db = getDB();
    const companies = db.profils_entreprises.slice(0, profil.companyMatches || 3);
    
    return (
      <div className="min-h-screen bg-[#0f172a] pb-24 animate-in slide-in-from-right-10 duration-500">
        <header className="p-6 border-b border-white/10 flex items-center gap-4 bg-slate-900/70 backdrop-blur-xl sticky top-0 z-50">
          <button onClick={() => setLocalSubView('main')} className="p-2 hover:bg-white/5 rounded-full">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h2 className="text-xl font-black italic uppercase">Mes contacts entreprises</h2>
        </header>
        <main className="p-6 max-w-4xl mx-auto space-y-4">
          {companies.map((company: any) => (
            <div key={company.id} className="bg-slate-900/70 p-6 rounded-[2rem] border border-white/10 flex items-center justify-between shadow-xl">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-[1.5rem] overflow-hidden bg-slate-800 border border-white/10">
                  <img src={company.logo_url} alt={company.nom_entreprise} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h3 className="text-lg font-black italic uppercase">{company.nom_entreprise}</h3>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{company.ville} • {company.secteur_activite}</p>
                </div>
              </div>
              <button className="bg-white text-slate-950 px-6 py-3 rounded-2xl font-black text-xs uppercase hover:bg-orange-500 hover:text-white transition-all">
                Contacter
              </button>
            </div>
          ))}
          {companies.length === 0 && (
            <div className="text-center py-20">
              <p className="text-slate-400 font-bold uppercase italic">Aucun contact pour le moment.</p>
            </div>
          )}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] pb-24 animate-in fade-in duration-500">
      <header className="p-6 border-b border-white/10 flex justify-between items-center bg-slate-900/70 backdrop-blur-xl sticky top-0 z-50">
        <Logo size="sm" />
        <button onClick={onLogout} className="text-red-500 text-[10px] font-black uppercase tracking-widest hover:text-red-400 transition-colors">Déconnexion</button>
      </header>
      
      <main className="p-6 max-w-4xl mx-auto space-y-8 mt-6">
        {/* Profile Card */}
        <section className="bg-gradient-to-br from-slate-900 to-slate-950 p-8 rounded-[2.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-orange-500/10 rounded-full blur-3xl"></div>
          
          <div className="absolute top-6 right-8">
            {!isEditing && (
              <button onClick={() => setIsEditing(true)} className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-[#FF731D] transition-colors" title="Modifier le profil">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                </svg>
              </button>
            )}
          </div>

          {isEditing ? (
            <div className="space-y-6 animate-in zoom-in-95 duration-300">
              <PhotoUpload currentUrl={editedData.photo_url} onPhotoChange={(url) => setEditedData({...editedData, photo_url: url})} />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" value={editedData.prenom} onChange={e => setEditedData({...editedData, prenom: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold" placeholder="Prénom" />
                <input type="text" value={editedData.nom} onChange={e => setEditedData({...editedData, nom: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold" placeholder="Nom" />
                <input type="text" value={editedData.identifiant} onChange={e => setEditedData({...editedData, identifiant: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold" placeholder="Identifiant" />
                <input type="tel" value={editedData.telephone} onChange={e => setEditedData({...editedData, telephone: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold" placeholder="Téléphone" />
                <input type="date" value={editedData.date_naissance} onChange={e => setEditedData({...editedData, date_naissance: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold" />
                <select value={editedData.genre} onChange={e => setEditedData({...editedData, genre: e.target.value as Genre})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold">
                  <option value="Homme">Homme</option>
                  <option value="Femme">Femme</option>
                  <option value="Autre">Autre</option>
                  <option value="Préfère ne pas répondre">Préfère ne pas répondre</option>
                </select>
                <textarea value={editedData.bio} onChange={e => setEditedData({...editedData, bio: e.target.value})} className="bg-slate-950 border border-white/10 p-4 rounded-[1.5rem] font-bold md:col-span-2" placeholder="Ma bio..." rows={3} />
              </div>

              {/* Gestion des CV dans l'édition profil */}
              <CVManagerInline
                cvList={editedData.cvList || []}
                onChange={list => setEditedData({...editedData, cvList: list})}
              />

              <div className="flex gap-4">
                <button onClick={handleSave} className="flex-1 bg-emerald-600 py-5 rounded-2xl font-black uppercase text-sm">Enregistrer</button>
                <button onClick={handleCancel} className="flex-1 bg-slate-800 py-5 rounded-2xl font-black uppercase text-sm">Annuler</button>
              </div>
            </div>
          ) : (
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-24 h-24 rounded-full border-4 border-[#FF731D] overflow-hidden shadow-xl shrink-0">
                {profil?.photo_url ? (
                  <img src={profil.photo_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-slate-800 flex items-center justify-center text-3xl font-black italic">{profil?.prenom?.[0] || 'U'}</div>
                )}
              </div>
              <div className="space-y-1 text-center md:text-left">
                <h2 className="text-3xl font-black italic tracking-tighter uppercase">{profil?.prenom || 'Nouveau'} {profil?.nom || 'Talent'}</h2>
                <p className="text-[#FF731D] text-xs font-black uppercase tracking-widest">@{profil.identifiant}</p>
                <p className="text-slate-400 text-sm italic font-medium max-w-sm mt-2">{profil.bio || "Aucune description renseignée."}</p>
                <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-4">
                  <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">📞 {profil?.telephone || 'Non renseigné'}</span>
                  <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">🎂 {profil?.date_naissance ? new Date(profil.date_naissance).toLocaleDateString() : 'Non renseignée'}</span>
                  <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">🔒 Via {user.auth_provider}</span>
                </div>
              </div>
            </div>
          )}
        </section>

        {/* Statistic Indicators Row */}
        <section className="grid grid-cols-3 gap-2 sm:gap-4">
          <div className="bg-slate-900/70 p-3 sm:p-4 rounded-[1.5rem] md:rounded-[2rem] border border-white/10 shadow-xl flex flex-col justify-center items-center text-center">
            <p className="text-[7px] sm:text-[9px] md:text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 leading-tight">Nombre de visites</p>
            <p className="text-lg sm:text-xl md:text-2xl font-black italic text-emerald-500">{profil.profileViews || 0}</p>
          </div>
          <button 
            onClick={() => setLocalSubView('contacts')} 
            className="bg-slate-900/70 p-3 sm:p-4 rounded-[1.5rem] md:rounded-[2rem] border border-white/10 shadow-xl hover:scale-105 transition-all group flex flex-col justify-center items-center text-center"
          >
            <p className="text-[7px] sm:text-[9px] md:text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 leading-tight">Matchs entreprises</p>
            <div className="flex items-center gap-1">
              <p className="text-lg sm:text-xl md:text-2xl font-black italic text-orange-500">{profil.companyMatches || 0}</p>
              <span className="hidden md:inline text-[8px] font-black text-orange-500 uppercase group-hover:translate-x-0.5 transition-transform">➔</span>
            </div>
          </button>
          <div className="bg-slate-900/70 p-3 sm:p-4 rounded-[1.5rem] md:rounded-[2rem] border border-white/10 shadow-xl flex flex-col justify-center items-center text-center">
            <p className="text-[7px] sm:text-[9px] md:text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1 leading-tight">Recom. actives</p>
            <p className="text-lg sm:text-xl md:text-2xl font-black italic text-blue-500">{profil.activeRecommendations || 0}</p>
          </div>
        </section>

        {/* Profile Visibility Toggle Section */}
        <section className="space-y-4">
          <div className="px-4">
            <h4 className="font-black italic uppercase tracking-tighter">Visibilité des Talent Cards</h4>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Contrôlez qui peut voir vos Talent Cards sur la plateforme</p>
          </div>
          <ToggleSwitch 
            checked={profil.isProfileVisible} 
            onChange={toggleVisibility} 
            label={profil.isProfileVisible ? 'Profil visible' : 'Profil masqué'} 
          />
        </section>

        {/* Talent Cards */}
        <section className="space-y-6">
          <div className="flex justify-between items-center px-4">
            <div className="space-y-1">
              <h3 className="font-black italic uppercase tracking-tighter text-xl">Talent Cards</h3>
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">{(profil.talentCards?.length || 0) + (profil.fiches?.length || 0)} Carte{ ((profil.talentCards?.length || 0) + (profil.fiches?.length || 0)) > 1 ? 's' : '' } active{ ((profil.talentCards?.length || 0) + (profil.fiches?.length || 0)) > 1 ? 's' : '' }</p>
            </div>
            <button
              onClick={onCreateCard}
              className="bg-[#FF731D] p-4 rounded-[1.5rem] text-white hover:scale-110 active:scale-95 transition-all shadow-lg shadow-orange-950/20"
              title="Créer une Talent Card"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
              </svg>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(profil.talentCards || []).map((card: TalentCard) => (
              <div key={card.id} className="bg-slate-900/70 p-6 rounded-[2rem] border border-white/10 shadow-xl hover:border-orange-500/30 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 w-24 h-24 bg-orange-500/5 rounded-full -mr-12 -mt-12"></div>
                <div className="flex justify-between items-start mb-3">
                  <h4 className="font-black italic uppercase tracking-tight text-lg text-[#FF731D]">{card.titre}</h4>
                  <div className="flex items-center gap-2 shrink-0 ml-2">
                    {(card as any).type_contrat && (
                      <span className="bg-orange-500/10 text-orange-400 text-[8px] font-black uppercase px-2 py-1 rounded border border-orange-500/20">{(card as any).type_contrat}</span>
                    )}
                    <button
                      onClick={() => {
                        if (confirm(`Supprimer la Talent Card "${card.titre}" ?`)) {
                          const updated = { ...profil, talentCards: profil.talentCards.filter((c: TalentCard) => c.id !== card.id) };
                          onUpdateProfile(updated);
                        }
                      }}
                      className="text-slate-600 hover:text-red-400 transition-colors p-1"
                      title="Supprimer cette carte"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                      </svg>
                    </button>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex gap-2 flex-wrap">
                    {card.competences.map((skill, idx) => (
                      <span key={idx} className="bg-white/5 px-3 py-1 rounded-lg text-[9px] font-black uppercase text-slate-400 border border-white/10">{skill}</span>
                    ))}
                  </div>
                  {(card as any).niveau && (
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Niveau: <span className="text-white">{(card as any).niveau}</span></p>
                  )}
                  {card.experience && (
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expérience: <span className="text-white">{card.experience}</span></p>
                  )}
                  {card.disponibilite && (
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Disponibilité: <span className="text-emerald-400">{card.disponibilite}</span></p>
                  )}
                  {(card as any).ville && (
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Ville: <span className="text-white">{(card as any).ville} {(card as any).code_postal}</span></p>
                  )}
                </div>
              </div>
            ))}
            {(!profil.talentCards || profil.talentCards.length === 0) && (
              <div className="bg-slate-900/70 border-2 border-dashed border-white/10 rounded-[2.5rem] p-12 text-center md:col-span-2">
                <p className="text-slate-400 text-xs font-bold uppercase tracking-widest italic">Aucune Talent Card créée</p>
                <button onClick={onCreateCard} className="text-[#FF731D] text-[10px] font-black uppercase mt-4 hover:underline">Créer ma première Talent Card ➔</button>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
};

// --- MAIN APP ---

const App: React.FC = () => {
  const [db, setDb] = useState<any>(null);
  const [view, setView] = useState<ViewState>('landing');
  const [user, setUser] = useState<Utilisateur | null>(null);
  const [profil, setProfil] = useState<any>(null);
  const [selectedRole, setSelectedRole] = useState<TypeUtilisateur | null>(null);
  const [socialPrefill, setSocialPrefill] = useState<any>(null);
  const [subView, setSubView] = useState('main');

  useEffect(() => {
    setDb(getDB());
  }, []);

  const handleStart = (role: TypeUtilisateur) => {
    setSelectedRole(role);
    setView('login');
  };

  const handleLogin = (u: Utilisateur) => {
    setUser(u);
    const currentDb = getDB();

    // ROLE-BASED REDIRECTION
    if (u.type_utilisateur === 'admin') {
      setView('admin_dashboard');
      return;
    }

    if (u.type_utilisateur === 'candidat') {
      const p = currentDb.profils_candidats.find((p: any) => p.utilisateur_id === u.id);
      // Ensure ProfilCandidat has all required fields initialized
      const enrichedProfil = {
        ...p,
        telephone: p.telephone || '',
        profileViews: p.profileViews || 0,
        companyMatches: p.companyMatches || 0,
        activeRecommendations: p.activeRecommendations || 0,
        isProfileVisible: p.isProfileVisible !== undefined ? p.isProfileVisible : true,
        talentCards: p.talentCards || []
      };
      setProfil(enrichedProfil);
      setView('candidate_dashboard');
    } else if (u.type_utilisateur === 'entreprise') {
      const p = currentDb.profils_entreprises.find((p: any) => p.utilisateur_id === u.id);
      setProfil(p);
      setView('company_dashboard');
    }
  };

  const handleSocialAuth = (provider: 'google' | 'facebook' | 'linkedin') => {
    // Simulated Social OAuth Response
    const mockSocialData = {
      google: { id: 'g123', email: 'julien.google@test.com', prenom: 'Julien', nom: 'G-Martin', photo: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=400&h=400&fit=crop', telephone: '0612345678' },
      facebook: { id: 'fb456', email: 'martin.fb@test.com', prenom: 'Martin', nom: 'F-Book', photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop', telephone: '0622334455' },
      linkedin: { id: 'li789', email: 'jmartin.pro@linkedin.com', prenom: 'Julien', nom: 'L-Pro', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop', telephone: '0699887766' },
    };

    const data = mockSocialData[provider];
    const currentDb = getDB();

    // 1. LINKING / AUTH FLOW
    const existingUser = currentDb.users.find((u: any) => u.email.toLowerCase() === data.email.toLowerCase());

    if (existingUser) {
      existingUser.auth_provider = provider;
      existingUser.social_id = data.id;
      saveDB(currentDb);
      handleLogin(existingUser);
    } else {
      // 2. FIRST TIME SOCIAL SIGNUP
      setSocialPrefill({
        email: data.email,
        prenom: data.prenom,
        nom: data.nom,
        photo_url: data.photo,
        telephone: data.telephone,
        auth_provider: provider,
        social_id: data.id
      });
      setView('signup');
    }
  };

  const handleSignup = (u: Utilisateur, p: ProfilCandidat) => {
    setUser(u);
    setProfil(p);
    setSocialPrefill(null);
    setView('candidate_dashboard');
  };

  const handleUpdateProfile = (newProfil: any) => {
    const currentDb = getDB();
    const idx = currentDb.profils_candidats.findIndex((p: any) => p.id === newProfil.id);
    if (idx !== -1) {
      currentDb.profils_candidats[idx] = newProfil;
      saveDB(currentDb);
      setProfil(newProfil);
    }
  };

  const handleCreateCard = (card: TalentCard) => {
    const updatedProfil = {
      ...profil,
      talentCards: [...(profil.talentCards || []), card]
    };
    handleUpdateProfile(updatedProfil);
    setView('candidate_dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setProfil(null);
    setSelectedRole(null);
    setSocialPrefill(null);
    setView('landing');
  };

  if (!db) return <div className="min-h-screen flex items-center justify-center font-black italic text-4xl animate-pulse" style={{ background: '#0f172a', color: '#FF4400' }}>TALENTBOOK...</div>;

  // Détermine la vue "retour" depuis une page légale
  const legalBackView = (): ViewState => {
    if (user?.type_utilisateur === 'candidat') return 'candidate_dashboard';
    if (user?.type_utilisateur === 'entreprise') return 'company_dashboard';
    if (user?.type_utilisateur === 'admin') return 'admin_dashboard';
    return 'landing';
  };

  // Pages légales — vues simples sans footer
  const LEGAL_VIEWS: ViewState[] = ['legal_cgu', 'legal_cgv', 'legal_mentions', 'legal_confidentialite', 'legal_contrat_b2b'];
  const isLegalView = LEGAL_VIEWS.includes(view);

  // Vues avec footer légal (toutes sauf les pages légales elles-mêmes)
  const FOOTER_VIEWS: ViewState[] = ['landing', 'login', 'signup', 'candidate_dashboard', 'company_dashboard', 'admin_dashboard'];
  const showFooter = FOOTER_VIEWS.includes(view) && subView === 'main';

  return (
    <div className="min-h-screen text-white overflow-x-hidden flex flex-col" className="bg-[#0f172a]">

      {/* ── Pages légales ── */}
      {view === 'legal_cgu' && <CGUPage onBack={() => setView(legalBackView())} />}
      {view === 'legal_cgv' && <CGVPage onBack={() => setView(legalBackView())} />}
      {view === 'legal_mentions' && <MentionsLegalesPage onBack={() => setView(legalBackView())} />}
      {view === 'legal_confidentialite' && <ConfidentialitePage onBack={() => setView(legalBackView())} />}
      {view === 'legal_contrat_b2b' && <ContratB2BPage onBack={() => setView(legalBackView())} />}

      {/* ── Pages principales ── */}
      {!isLegalView && (
        <div className="flex-1 flex flex-col">
          {view === 'landing' && <LandingView onStart={handleStart} />}

          {view === 'login' && (
            <LoginView
              role={selectedRole}
              onLogin={handleLogin}
              onSocialAuth={handleSocialAuth}
              onSwitchToSignup={() => { setSocialPrefill(null); setView('signup'); }}
              onBack={() => setView('landing')}
            />
          )}

          {view === 'signup' && (
            <SignupView
              role={selectedRole}
              initialData={socialPrefill}
              onSignup={handleSignup}
              onSwitchToLogin={() => setView('login')}
              onBack={() => { setSocialPrefill(null); setView('landing'); }}
              onShowLegal={(page) => setView(page === 'cgu' ? 'legal_cgu' : 'legal_confidentialite')}
            />
          )}

          {view === 'candidate_dashboard' && subView === 'edit_fiche' && (
            <CandidateFicheView
              profil={profil}
              onSave={(fiche) => {
                const updatedProfil = { ...profil, fiches: [...(profil.fiches || []), fiche] };
                handleUpdateProfile(updatedProfil);
                setSubView('main');
              }}
              onCancel={() => setSubView('main')}
            />
          )}

          {view === 'candidate_dashboard' && subView === 'main' && (
            <CandidateDashboard
              user={user}
              profil={profil}
              onLogout={handleLogout}
              onUpdateProfile={handleUpdateProfile}
              onCreateCard={() => setView('talent_card')}
              setSubView={setSubView}
            />
          )}

          {view === 'company_dashboard' && (
            <CompanyDashboard profil={profil} onLogout={handleLogout} />
          )}

          {view === 'talent_card' && profil && (
            <TalentCardView
              profil={profil}
              onSave={handleCreateCard}
              onCancel={() => setView('candidate_dashboard')}
            />
          )}

          {view === 'admin_dashboard' && (
            <div className="min-h-screen flex flex-col items-center justify-center p-12 text-center space-y-8 animate-in slide-in-from-top-10 duration-500">
              <Logo size="lg" className="mx-auto" />
              <h2 className="text-4xl font-black uppercase italic tracking-tighter text-emerald-500">Console d'administration</h2>
              <div className="bg-slate-900/70 p-8 rounded-[2.5rem] border border-white/10 w-full max-w-2xl text-left space-y-4">
                <h3 className="text-xl font-bold uppercase tracking-widest text-[#FF731D]">Statistiques Temps Réel</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-950 p-4 rounded-2xl border border-white/10">
                    <p className="text-xs font-bold text-slate-400 uppercase">Utilisateurs</p>
                    <p className="text-3xl font-black italic">{db.users.length}</p>
                  </div>
                  <div className="bg-slate-950 p-4 rounded-2xl border border-white/10">
                    <p className="text-xs font-bold text-slate-400 uppercase">Profils Talents</p>
                    <p className="text-3xl font-black italic">{db.profils_candidats.length}</p>
                  </div>
                </div>
                <div className="pt-6">
                  <button
                    onClick={() => setView('mini_scope_admin')}
                    className="w-full bg-emerald-600 py-5 rounded-[1.5rem] font-black text-lg hover:bg-emerald-500 transition-all uppercase italic shadow-xl"
                  >
                    Gestion Mini-SCOPE
                  </button>
                </div>
              </div>
              <button onClick={handleLogout} className="bg-red-500 px-10 py-5 rounded-[2.5rem] font-black text-lg hover:bg-red-600 transition-all uppercase italic shadow-xl">Déconnexion</button>
            </div>
          )}

          {view === 'mini_scope_admin' && (
            <MiniScopeAdminView onBack={() => setView('admin_dashboard')} />
          )}

          {view === 'metiers_explorer' && (
            <div className="min-h-screen flex flex-col items-center justify-center p-12 text-center space-y-8 animate-in fade-in duration-500">
              <Logo size="lg" className="mx-auto" />
              <h2 className="text-3xl font-black uppercase italic tracking-tighter">Module en développement</h2>
              <p className="text-slate-400 max-w-sm">Cette interface est en cours de déploiement sécurisé sur nos serveurs.</p>
              <button onClick={() => setView(user?.type_utilisateur === 'admin' ? 'admin_dashboard' : 'candidate_dashboard')} className="bg-[#FF731D] px-10 py-5 rounded-[2.5rem] font-black text-lg hover:scale-105 active:scale-95 transition-all shadow-xl shadow-orange-950/20">RETOUR</button>
            </div>
          )}

          {/* ── Footer légal ── */}
          {showFooter && (
            <LegalFooter
              onNavigate={(page) => {
                const map: Record<string, ViewState> = {
                  'cgv': 'legal_cgv',
                  'cgu': 'legal_cgu',
                  'mentions': 'legal_mentions',
                  'confidentialite': 'legal_confidentialite',
                  'contrat-b2b': 'legal_contrat_b2b',
                };
                setView(map[page]);
              }}
            />
          )}
        </div>
      )}

      {/* ── Cookie Banner CNIL ── */}
      <CookieBanner onShowConfidentialite={() => setView('legal_confidentialite')} />
    </div>
  );
};

export default App;
