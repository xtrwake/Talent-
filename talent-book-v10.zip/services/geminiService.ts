
import { GoogleGenAI, Type } from "@google/genai";

// Helper to get a fresh instance of GoogleGenAI as recommended for latest API key usage
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateMockProfiles = async () => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.0-flash',
    contents: 'Génère 6 profils de talents fictifs pour une plateforme de recrutement. Inclus : nom complet, métier tech/marketing, 5 compétences clés, et disponibilité.',
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            name: { type: Type.STRING },
            role: { type: Type.STRING },
            experience: { type: Type.STRING },
            skills: { type: Type.ARRAY, items: { type: Type.STRING } },
            availability: { type: Type.STRING },
          },
          required: ['id', 'name', 'role', 'skills', 'availability']
        }
      }
    }
  });

  try {
    // Correctly using the .text property (not a method) as per SDK guidelines
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Error parsing Gemini response", e);
    return [];
  }
};

export const fetchCitiesByZip = async (zipCode: string) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents: `Génère la liste complète et structurée des villes françaises pour le code postal suivant : ${zipCode}. 
      Réponds uniquement avec un tableau JSON d'objets. Chaque objet doit avoir : 
      postal_code (5 chiffres), city_name (nom officiel), department_code, department_name, region_name.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              postal_code: { type: Type.STRING },
              city_name: { type: Type.STRING },
              department_code: { type: Type.STRING },
              department_name: { type: Type.STRING },
              region_name: { type: Type.STRING },
            },
            required: ['postal_code', 'city_name', 'department_name']
          }
        }
      }
    });
    // Correctly using the .text property (not a method) as per SDK guidelines
    return JSON.parse(response.text || '[]');
  } catch (e) {
    console.error("Error fetching cities", e);
    return [];
  }
};
