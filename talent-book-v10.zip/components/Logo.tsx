
import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showText?: boolean;
}

// Tailles px du T selon le contexte
const T_SIZES = {
  sm: 24,
  md: 36,
  lg: 56,
  xl: 80,
};

// Le T stylisé SVG — barre horizontale + fût + empattements bas (style slab-serif / Facebook)
export const TLogo: React.FC<{ px?: number; className?: string }> = ({ px = 36, className = "" }) => (
  <svg
    width={px}
    height={px}
    viewBox="0 0 60 60"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    style={{ flexShrink: 0 }}
  >
    <rect width="60" height="60" rx="13" fill="#FF6B1A" />
    {/* Barre horizontale du T */}
    <rect x="9" y="12" width="42" height="9" rx="4.5" fill="white" />
    {/* Fût vertical */}
    <rect x="25" y="12" width="10" height="34" rx="2.5" fill="white" />
    {/* Empattement bas gauche */}
    <rect x="16" y="39" width="12" height="7" rx="3.5" fill="white" />
    {/* Empattement bas droit */}
    <rect x="32" y="39" width="12" height="7" rx="3.5" fill="white" />
  </svg>
);

export const Logo: React.FC<LogoProps> = ({ size = 'md', className = '', showText = true }) => {
  const px = T_SIZES[size];
  const textClass = {
    sm: 'text-base',
    md: 'text-2xl',
    lg: 'text-4xl',
    xl: 'text-6xl',
  }[size];

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      <TLogo px={px} />
      {showText && (
        <span className={`${textClass} font-black tracking-tight text-white leading-none`} style={{ marginLeft: '-2px' }}>
          alent<span className="text-[#FF6B1A]">book</span>
        </span>
      )}
    </div>
  );
};

// Utilisé partout où "Talentbook" ou "Talent" apparaît dans le texte
export const BrandText: React.FC<{ text: string; className?: string }> = ({ text, className = "" }) => {
  const parts = text.split(/(Talentbook|Talent)/g);

  return (
    <span className={`${className} inline-flex items-center flex-wrap`} style={{ gap: '0 2px' }}>
      {parts.map((part, i) => {
        if (part === "Talentbook") {
          return (
            <span key={i} className="inline-flex items-center" style={{ gap: 2 }}>
              <TLogo px={18} />
              <span className="font-black tracking-tight leading-none" style={{ marginLeft: '-1px' }}>
                alent<span className="text-[#FF6B1A]">book</span>
              </span>
            </span>
          );
        }
        if (part === "Talent") {
          return (
            <span key={i} className="inline-flex items-center" style={{ gap: 2 }}>
              <TLogo px={18} />
              <span className="font-black tracking-tight leading-none" style={{ marginLeft: '-1px' }}>
                alent
              </span>
            </span>
          );
        }
        return <span key={i}>{part}</span>;
      })}
    </span>
  );
};
