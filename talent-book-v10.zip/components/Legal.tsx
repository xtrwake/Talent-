import React, { useState, useEffect, useRef } from 'react';
import { Logo } from './Logo';
import { LEGAL_CONFIG, legalField, IS_DEV } from '../config/legal.config';

const C = LEGAL_CONFIG.company;

// ─── Badge "À compléter" ─────────────────────────────────────
const Todo: React.FC<{ label?: string }> = ({ label }) => {
  if (!IS_DEV) return <span>{label || ''}</span>;
  return (
    <span className="inline-flex items-center gap-1 bg-yellow-400/20 border border-yellow-400/50 text-yellow-300 text-[10px] font-black uppercase px-2 py-0.5 rounded mx-1">
      ⚠ {label || 'À COMPLÉTER'}
    </span>
  );
};

const Field: React.FC<{ value: string; label?: string }> = ({ value, label }) => {
  if (value && value.trim() !== '') return <span>{value}</span>;
  return <Todo label={label} />;
};

// ─── Layout page légale ──────────────────────────────────────
const LegalLayout: React.FC<{
  title: string;
  subtitle: string;
  version?: string;
  children: React.ReactNode;
  onBack: () => void;
}> = ({ title, subtitle, version, children, onBack }) => {
  const handlePrint = () => window.print();

  return (
    <div className="min-h-screen bg-[#1C2333] text-white pb-24">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0D1220]/95 backdrop-blur border-b border-white/10 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 transition-all"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <Logo size="sm" />
        </div>
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 bg-[#FF4D00] text-white text-xs font-black uppercase px-4 py-2.5 rounded-xl hover:bg-orange-500 transition-all"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
          </svg>
          Imprimer / PDF
        </button>
      </header>

      {/* Titre */}
      <div className="max-w-4xl mx-auto px-6 pt-12 pb-8">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-4xl font-black italic uppercase tracking-tighter text-white">{title}</h1>
            <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mt-2">{subtitle}</p>
          </div>
          <div className="text-right shrink-0">
            {version && <div className="text-xs font-bold text-slate-500 uppercase">Version {version}</div>}
            <div className="text-xs font-bold text-slate-500 uppercase mt-1">Mise à jour : {C.last_updated}</div>
          </div>
        </div>
        <div className="mt-6 h-1 bg-gradient-to-r from-[#FF4D00] to-transparent rounded-full" />
      </div>

      {/* Contenu */}
      <div className="max-w-4xl mx-auto px-6 space-y-8 legal-content">
        {children}
      </div>

      {/* Print styles */}
      <style>{`
        @media print {
          header, button { display: none !important; }
          body { background: white !important; color: black !important; }
          .legal-content { color: black !important; }
        }
      `}</style>
    </div>
  );
};

const Section: React.FC<{ title: string; children: React.ReactNode; accent?: string }> = ({ title, accent = 'orange', children }) => (
  <section className="bg-slate-900/50 rounded-3xl border border-white/10 p-8">
    <h2 className={`text-xl font-black italic uppercase tracking-tighter mb-6 ${accent === 'emerald' ? 'text-emerald-400' : accent === 'blue' ? 'text-blue-400' : 'text-[#FF4D00]'}`}>
      {title}
    </h2>
    <div className="space-y-4 text-slate-300 text-sm leading-relaxed">
      {children}
    </div>
  </section>
);

const Art: React.FC<{ n: string; title: string; children: React.ReactNode }> = ({ n, title, children }) => (
  <div className="border-l-2 border-[#FF4D00]/40 pl-6">
    <h3 className="font-black text-white uppercase tracking-widest text-xs mb-3">Article {n} — {title}</h3>
    <div className="text-slate-300 text-sm leading-relaxed space-y-2">{children}</div>
  </div>
);

// ─────────────────────────────────────────────────────────────
// PAGE CGU
// ─────────────────────────────────────────────────────────────
export const CGUPage: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <LegalLayout title="Conditions Générales d'Utilisation" subtitle="TalentBook — Plateforme GMS" version={C.cgu_version} onBack={onBack}>
    <Section title="Présentation de la plateforme">
      <p>
        La plateforme <strong>TalentBook</strong>, propriété de la société{' '}
        <Field value={C.name} /> ({C.legal_form}), membre du groupe{' '}
        <Field value={C.group} />, est une solution de mise en relation entre candidats et
        entreprises du secteur GMS (Grande et Moyenne Surface).
      </p>
      <p>
        Siège social : <Field value={`${C.address}, ${C.zip} ${C.city}`} label="adresse siège" /> —
        SIRET : <Field value={C.siret} label="SIRET" /> —
        RCS : <Field value={`${C.rcs} ${C.rcs_city}`} label="RCS" />
      </p>
      <p>Contact : <a href={`mailto:${C.email_contact}`} className="text-[#FF4D00] underline">{C.email_contact}</a></p>
    </Section>

    <Section title="Articles">
      <Art n="1" title="Objet">
        <p>Les présentes CGU régissent l'utilisation de la plateforme TalentBook par les candidats (ci-après « Talents »). Elles définissent les droits et obligations des utilisateurs dans le cadre de la mise en relation avec des entreprises du secteur GMS.</p>
      </Art>
      <Art n="2" title="Accès au service">
        <p>L'accès à TalentBook est gratuit pour les candidats. L'inscription nécessite la création d'un compte avec des informations exactes et à jour. Toute inscription frauduleuse entraîne la résiliation immédiate du compte.</p>
        <p>Le candidat est responsable de la confidentialité de ses identifiants et de toute activité réalisée sous son compte.</p>
      </Art>
      <Art n="3" title="Création de compte et Talent Cards">
        <p>Le candidat peut créer des « Talent Cards » présentant son profil, ses compétences et sa disponibilité. Ces fiches constituent l'élément central de la mise en relation avec les recruteurs.</p>
        <p>Le candidat garantit l'exactitude des informations renseignées et s'engage à les maintenir à jour.</p>
      </Art>
      <Art n="4" title="Données personnelles">
        <p>Le traitement des données est régi par la Politique de Confidentialité accessible sur la plateforme. Conformément au RGPD, le candidat dispose d'un droit d'accès, de rectification, d'effacement et de portabilité de ses données. Ces droits s'exercent auprès de : <a href={`mailto:${C.email_rgpd}`} className="text-[#FF4D00] underline">{C.email_rgpd}</a></p>
      </Art>
      <Art n="5" title="Visibilité du profil">
        <p>Le candidat contrôle la visibilité de son profil via le tableau de bord. Un profil masqué n'apparaît pas dans les résultats de recherche des entreprises. TalentBook ne garantit pas de mise en relation mais s'engage à mettre à disposition les outils nécessaires.</p>
      </Art>
      <Art n="6" title="Propriété intellectuelle">
        <p>Les contenus publiés par le candidat sur TalentBook (CV, descriptions) restent sa propriété. Il accorde à TalentBook une licence non exclusive d'utilisation pour les besoins du service.</p>
      </Art>
      <Art n="7" title="Responsabilité">
        <p>TalentBook ne saurait être tenu responsable des décisions de recrutement prises par les entreprises, ni des inexactitudes dans les offres publiées. La plateforme est un intermédiaire technique.</p>
      </Art>
      <Art n="8" title="Résiliation">
        <p>Le candidat peut supprimer son compte à tout moment depuis les paramètres. Les données sont effacées dans un délai de 30 jours, sauf obligation légale de conservation.</p>
      </Art>
      <Art n="9" title="Modification des CGU">
        <p>TalentBook se réserve le droit de modifier les présentes CGU. Toute modification est notifiée par email. L'utilisation continue de la plateforme après notification vaut acceptation des nouvelles conditions.</p>
      </Art>
      <Art n="10" title="Droit applicable">
        <p>Les présentes CGU sont soumises au droit français. Tout litige relève de la compétence exclusive du Tribunal de Commerce de <Field value={C.court_city} label="ville tribunal" />.</p>
      </Art>
    </Section>
  </LegalLayout>
);

// ─────────────────────────────────────────────────────────────
// PAGE CGV
// ─────────────────────────────────────────────────────────────
export const CGVPage: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <LegalLayout title="Conditions Générales de Vente" subtitle="TalentBook — Offre entreprises GMS" version={C.cgv_version} onBack={onBack}>
    <Section title="Présentation" accent="blue">
      <p>Les présentes CGV s'appliquent à toutes les ventes de services réalisées par <Field value={C.name} /> (<Field value={C.legal_form} />) auprès des entreprises clientes du secteur GMS.</p>
      <p>TVA intracommunautaire : <Field value={C.vat_number} label="numéro TVA" /></p>
    </Section>
    <Section title="Articles" accent="blue">
      <Art n="1" title="Objet et champ d'application">
        <p>Les présentes CGV définissent les conditions dans lesquelles TalentBook fournit ses services de mise en relation aux entreprises clientes. Elles prévalent sur tout autre document émanant de l'acheteur.</p>
      </Art>
      <Art n="2" title="Services proposés">
        <p>TalentBook propose : (i) l'accès à une base de candidats qualifiés du secteur GMS, (ii) un moteur de matching basé sur le référentiel Mini-SCOPE, (iii) des crédits de mise en relation, (iv) des outils de gestion RH.</p>
      </Art>
      <Art n="3" title="Tarification">
        <p>Les prix sont établis selon la grille tarifaire en vigueur, disponible sur demande. Les prix s'entendent HT. La TVA applicable est de 20 %. Toute commande vaut acceptation des prix et conditions.</p>
      </Art>
      <Art n="4" title="Commande et contrat">
        <p>Toute commande est formalisée par la signature du contrat B2B disponible sur la plateforme. L'entreprise cliente doit avoir accepté les présentes CGV et le contrat B2B avant tout accès aux services payants.</p>
      </Art>
      <Art n="5" title="Paiement">
        <p>Le paiement est dû à réception de facture, sauf conditions particulières négociées. Tout retard de paiement entraîne l'application de pénalités au taux légal majoré de 5 points, ainsi qu'une indemnité forfaitaire de 40 € pour frais de recouvrement.</p>
      </Art>
      <Art n="6" title="Crédits et utilisation">
        <p>Les crédits achetés sont valables 12 mois à compter de leur acquisition. Ils ne sont ni remboursables ni cessibles. Leur utilisation est limitée au compte de l'entreprise cliente.</p>
      </Art>
      <Art n="7" title="Garanties et responsabilité">
        <p>TalentBook garantit la mise à disposition du service mais ne garantit pas de résultat en matière de recrutement. La responsabilité de TalentBook est limitée au montant des sommes versées par le client au cours des 12 derniers mois.</p>
      </Art>
      <Art n="8" title="Résiliation">
        <p>En cas de manquement grave par l'une des parties, la partie lésée peut résilier le contrat par lettre recommandée avec AR, avec un préavis de 30 jours.</p>
      </Art>
      <Art n="9" title="Droit applicable — Juridiction">
        <p>Les présentes CGV sont régies par le droit français. Tout litige sera porté devant le Tribunal de Commerce de <Field value={C.court_city} label="ville tribunal" />.</p>
      </Art>
    </Section>
  </LegalLayout>
);

// ─────────────────────────────────────────────────────────────
// PAGE MENTIONS LÉGALES
// ─────────────────────────────────────────────────────────────
export const MentionsLegalesPage: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <LegalLayout title="Mentions Légales" subtitle="TalentBook — Groupe XtrLabs" onBack={onBack}>
    <Section title="Éditeur du site">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <p><span className="text-slate-500 text-xs uppercase font-bold">Raison sociale</span><br /><strong>{C.name} ({C.legal_form})</strong></p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">Groupe</span><br />{C.group}</p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">SIRET</span><br /><Field value={C.siret} label="SIRET" /></p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">RCS</span><br /><Field value={`${C.rcs} ${C.rcs_city}`} label="RCS + ville" /></p>
        </div>
        <div className="space-y-2">
          <p><span className="text-slate-500 text-xs uppercase font-bold">Siège social</span><br /><Field value={`${C.address}, ${C.zip} ${C.city}`} label="adresse" /></p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">TVA</span><br /><Field value={C.vat_number} label="TVA intracommunautaire" /></p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">Représentant légal</span><br /><Field value={`${C.legal_rep_name}, ${C.legal_rep_title}`} label="représentant" /></p>
          <p><span className="text-slate-500 text-xs uppercase font-bold">Contact</span><br /><a href={`mailto:${C.email_contact}`} className="text-[#FF4D00] underline">{C.email_contact}</a></p>
        </div>
      </div>
    </Section>
    <Section title="Hébergement">
      <p><span className="text-slate-500 text-xs uppercase font-bold">Hébergeur</span> : <Field value={C.host_name} label="nom hébergeur" /></p>
      <p><span className="text-slate-500 text-xs uppercase font-bold">Adresse</span> : <Field value={C.host_address} label="adresse hébergeur" /></p>
    </Section>
    <Section title="Propriété intellectuelle">
      <p>L'ensemble du contenu de la plateforme TalentBook (textes, images, logos, interface) est protégé par le droit d'auteur et appartient à {C.name} ou à ses partenaires. Toute reproduction sans autorisation est interdite.</p>
      <p>La marque <strong>TalentBook</strong> et le logo associé sont des marques de {C.group}.</p>
    </Section>
    <Section title="Cookies et traçage">
      <p>La plateforme utilise des cookies nécessaires au fonctionnement du service, ainsi que des cookies analytiques et marketing soumis à votre consentement. Pour plus d'informations, consultez notre Politique de Confidentialité.</p>
    </Section>
    <Section title="Droit applicable">
      <p>Le site est soumis au droit français. Tout litige relève de la compétence des tribunaux de <Field value={C.court_city} label="ville tribunal" />.</p>
    </Section>
  </LegalLayout>
);

// ─────────────────────────────────────────────────────────────
// PAGE RGPD / CONFIDENTIALITÉ
// ─────────────────────────────────────────────────────────────
export const ConfidentialitePage: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <LegalLayout title="Politique de Confidentialité" subtitle="RGPD — Protection des données personnelles" onBack={onBack}>
    <Section title="Responsable du traitement" accent="emerald">
      <p><Field value={C.name} /> (<Field value={C.legal_form} />), <Field value={`${C.address}, ${C.zip} ${C.city}`} label="adresse" /> — <a href={`mailto:${C.email_rgpd}`} className="text-emerald-400 underline">{C.email_rgpd}</a></p>
    </Section>
    <Section title="Données collectées et finalités" accent="emerald">
      <div className="overflow-x-auto">
        <table className="w-full text-xs border-collapse">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left py-2 pr-4 text-emerald-400 font-black uppercase">Catégorie</th>
              <th className="text-left py-2 pr-4 text-emerald-400 font-black uppercase">Données</th>
              <th className="text-left py-2 pr-4 text-emerald-400 font-black uppercase">Finalité</th>
              <th className="text-left py-2 text-emerald-400 font-black uppercase">Base légale</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {[
              ['Identification', 'Nom, prénom, email, téléphone', 'Création et gestion du compte', 'Contrat'],
              ['Profil professionnel', 'CV, compétences, expériences', 'Mise en relation avec recruteurs', 'Contrat + consentement'],
              ['Navigation', 'Logs, adresse IP, cookies', 'Sécurité et amélioration du service', 'Intérêt légitime'],
              ['Analytique', 'Pages visitées, actions', 'Statistiques d\'utilisation', 'Consentement'],
              ['Marketing', 'Préférences, comportement', 'Personnalisation', 'Consentement'],
            ].map(([cat, data, purpose, base]) => (
              <tr key={cat}>
                <td className="py-2 pr-4 font-bold text-white">{cat}</td>
                <td className="py-2 pr-4 text-slate-400">{data}</td>
                <td className="py-2 pr-4 text-slate-400">{purpose}</td>
                <td className="py-2 text-emerald-400 font-bold">{base}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Section>
    <Section title="Durées de conservation" accent="emerald">
      <ul className="space-y-2">
        <li>• Données de compte : durée de la relation + 3 ans</li>
        <li>• CV et Talent Cards : suppression sur demande ou à la clôture du compte</li>
        <li>• Logs de connexion : 12 mois</li>
        <li>• Données de facturation : 10 ans (obligation légale)</li>
      </ul>
    </Section>
    <Section title="Vos droits (RGPD)" accent="emerald">
      <p>Conformément au RGPD, vous disposez des droits suivants :</p>
      <ul className="space-y-1 mt-2">
        <li>• <strong>Accès</strong> : obtenir une copie de vos données</li>
        <li>• <strong>Rectification</strong> : corriger des données inexactes</li>
        <li>• <strong>Effacement</strong> : demander la suppression de vos données</li>
        <li>• <strong>Portabilité</strong> : recevoir vos données dans un format structuré</li>
        <li>• <strong>Opposition</strong> : vous opposer à certains traitements</li>
        <li>• <strong>Limitation</strong> : limiter temporairement un traitement</li>
      </ul>
      <p className="mt-4">Pour exercer vos droits : <a href={`mailto:${C.email_rgpd}`} className="text-emerald-400 underline font-bold">{C.email_rgpd}</a></p>
      <p className="mt-2">En cas de réclamation non résolue, vous pouvez saisir la <strong>CNIL</strong> (www.cnil.fr).</p>
    </Section>
    <Section title="Sous-traitants & transferts hors UE" accent="emerald">
      <p>TalentBook peut faire appel à des sous-traitants techniques (hébergement, analytics). Tout transfert hors UE est encadré par des clauses contractuelles types approuvées par la Commission Européenne.</p>
      <p className="mt-2">Liste des sous-traitants disponible sur demande à : <a href={`mailto:${C.email_rgpd}`} className="text-emerald-400 underline">{C.email_rgpd}</a></p>
    </Section>
    <Section title="Cookies" accent="emerald">
      <p>La plateforme utilise 3 catégories de cookies :</p>
      <ul className="mt-2 space-y-2">
        <li><strong className="text-white">Nécessaires</strong> — Toujours actifs. Essentiels au fonctionnement (session, sécurité).</li>
        <li><strong className="text-white">Analytiques</strong> — Soumis à consentement. Mesure d'audience anonymisée.</li>
        <li><strong className="text-white">Marketing</strong> — Soumis à consentement. Personnalisation et retargeting.</li>
      </ul>
      <p className="mt-3">Vous pouvez modifier vos préférences à tout moment via le bandeau de gestion des cookies.</p>
    </Section>
  </LegalLayout>
);

// ─────────────────────────────────────────────────────────────
// PAGE CONTRAT B2B
// ─────────────────────────────────────────────────────────────
export const ContratB2BPage: React.FC<{ onBack: () => void; onAccept?: () => void; showAcceptButton?: boolean }> = ({ onBack, onAccept, showAcceptButton = false }) => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [hasScrolled, setHasScrolled] = useState(false);
  const [accepted, setAccepted] = useState(false);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    const isAtBottom = el.scrollHeight - el.scrollTop <= el.clientHeight + 50;
    if (isAtBottom) setHasScrolled(true);
  };

  return (
    <LegalLayout title="Contrat B2B Type" subtitle="TalentBook — Services entreprises GMS" version="1.0" onBack={onBack}>
      <Section title="Parties contractantes" accent="blue">
        <p><strong>Prestataire :</strong> <Field value={C.name} /> (<Field value={C.legal_form} />), <Field value={`${C.address}, ${C.zip} ${C.city}`} label="adresse" />, représentée par <Field value={`${C.legal_rep_name}, ${C.legal_rep_title}`} label="représentant légal" />.</p>
        <p className="mt-2"><strong>Client :</strong> L'entreprise dont les coordonnées figurent dans le bon de commande ou le formulaire d'onboarding.</p>
      </Section>

      <div
        ref={contentRef}
        onScroll={handleScroll}
        className={`space-y-6 ${showAcceptButton ? 'max-h-[60vh] overflow-y-auto pr-2 scrollbar-thin' : ''}`}
      >
        {[
          ['1', 'Objet du contrat', 'Le présent contrat a pour objet de définir les conditions dans lesquelles TalentBook met à disposition du Client ses services de recrutement spécialisés GMS, incluant l\'accès à la base de candidats, au moteur de matching Mini-SCOPE et aux outils associés.'],
          ['2', 'Durée', 'Le contrat est conclu pour une durée initiale de 12 mois à compter de la date de signature. Il se renouvelle tacitement par périodes de 12 mois, sauf dénonciation par l\'une des parties avec un préavis de 30 jours.'],
          ['3', 'Obligations de TalentBook', 'TalentBook s\'engage à : (i) maintenir la plateforme accessible 99,5% du temps (hors maintenance planifiée), (ii) qualifier les candidats selon le référentiel Mini-SCOPE, (iii) protéger les données conformément au RGPD, (iv) fournir un support client dans un délai de 48h ouvrées.'],
          ['4', 'Obligations du Client', 'Le Client s\'engage à : (i) utiliser la plateforme dans le respect des CGV et de la réglementation en vigueur, (ii) ne pas contacter directement les candidats sans utiliser les crédits prévus, (iii) maintenir la confidentialité des informations candidates, (iv) ne pas céder l\'accès à des tiers.'],
          ['5', 'Tarification et facturation', 'La facturation est réalisée selon la grille tarifaire en vigueur au moment de la commande. Les factures sont émises mensuellement et payables à 30 jours. Tout retard entraîne des pénalités selon les CGV.'],
          ['6', 'Crédits et mise en relation', 'Chaque prise de contact avec un candidat consomme un crédit. Les crédits sont valables 12 mois. En cas de profil non disponible ou de données incorrectes, le crédit est restitué sous 5 jours ouvrés.'],
          ['7', 'Confidentialité', 'Chaque partie s\'engage à maintenir strictement confidentielle toute information obtenue dans le cadre du présent contrat. Cette obligation survit à la résiliation pour une durée de 3 ans.'],
          ['8', 'Protection des données (DPA)', 'TalentBook agit en qualité de sous-traitant au sens du RGPD pour les données des candidats transmises au Client. Les conditions de traitement sont définies dans l\'annexe DPA jointe au présent contrat.'],
          ['9', 'Propriété intellectuelle', 'Le Client obtient un droit d\'usage non exclusif de la plateforme pour la durée du contrat. TalentBook conserve l\'intégralité des droits de propriété intellectuelle sur la plateforme et ses algorithmes.'],
          ['10', 'Résiliation', 'En cas de manquement grave non corrigé dans les 15 jours suivant mise en demeure, la partie lésée peut résilier le contrat sans préavis. Les sommes dues restent exigibles.'],
          ['11', 'Limitation de responsabilité', 'La responsabilité de TalentBook est limitée au montant des sommes effectivement perçues du Client au cours des 12 mois précédant l\'incident. TalentBook n\'est pas responsable des décisions de recrutement.'],
          ['12', 'Droit applicable', `Le présent contrat est soumis au droit français. En cas de litige, les parties s\'efforceront de trouver une solution amiable. À défaut, le litige sera porté devant le Tribunal de Commerce de ${legalField(C.court_city, '[ville tribunal]')}.`],
        ].map(([n, title, content]) => (
          <Section key={n} title={`Articles`} accent="blue">
            <Art n={n} title={title}><p>{content}</p></Art>
          </Section>
        ))}
      </div>

      {showAcceptButton && (
        <div className="sticky bottom-0 bg-[#0D1220]/95 backdrop-blur border-t border-white/10 p-6 mt-8 rounded-b-3xl">
          {!hasScrolled && (
            <p className="text-center text-yellow-400 text-xs font-bold uppercase tracking-widest mb-4 animate-pulse">
              ↓ Faites défiler jusqu'en bas pour activer le bouton d'acceptation
            </p>
          )}
          <label className={`flex items-start gap-3 cursor-pointer mb-4 ${!hasScrolled ? 'opacity-40 pointer-events-none' : ''}`}>
            <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} className="mt-1 w-4 h-4 accent-orange-500" />
            <span className="text-sm text-slate-300">
              J'ai lu et j'accepte l'intégralité du contrat B2B TalentBook, version 1.0, ainsi que ses annexes.
            </span>
          </label>
          <button
            onClick={() => accepted && onAccept?.()}
            disabled={!hasScrolled || !accepted}
            className="w-full bg-[#FF4D00] text-white font-black uppercase text-sm py-4 rounded-2xl transition-all disabled:opacity-30 disabled:cursor-not-allowed hover:bg-orange-500"
          >
            J'ai lu et j'accepte le contrat ✓
          </button>
        </div>
      )}
    </LegalLayout>
  );
};

// ─────────────────────────────────────────────────────────────
// COOKIE BANNER (CNIL 2024)
// ─────────────────────────────────────────────────────────────
type CookieConsent = {
  necessary: true;
  analytics: boolean;
  marketing: boolean;
  decided: boolean;
  timestamp: number;
};

const COOKIE_KEY = 'talentbook_cookie_consent';

export const CookieBanner: React.FC<{ onShowConfidentialite: () => void }> = ({ onShowConfidentialite }) => {
  const [visible, setVisible] = useState(false);
  const [customizing, setCustomizing] = useState(false);
  const [prefs, setPrefs] = useState({ analytics: false, marketing: false });

  useEffect(() => {
    try {
      const stored = localStorage.getItem(COOKIE_KEY);
      if (!stored) setVisible(true);
    } catch { setVisible(true); }
  }, []);

  const save = (analytics: boolean, marketing: boolean) => {
    const consent: CookieConsent = { necessary: true, analytics, marketing, decided: true, timestamp: Date.now() };
    try { localStorage.setItem(COOKIE_KEY, JSON.stringify(consent)); } catch {}
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[9999] p-4 md:p-6">
      <div className="max-w-4xl mx-auto bg-[#0D1220] border border-white/20 rounded-3xl shadow-2xl p-6">
        {!customizing ? (
          <>
            <div className="flex items-start gap-4 mb-5">
              <div className="shrink-0 text-2xl">🍪</div>
              <div>
                <h3 className="font-black text-white uppercase tracking-tight text-base mb-1">Gestion des cookies</h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  TalentBook utilise des cookies pour assurer le bon fonctionnement du service et, avec votre consentement, pour analyser l'utilisation et personnaliser votre expérience.{' '}
                  <button onClick={onShowConfidentialite} className="text-[#FF4D00] underline">En savoir plus</button>
                </p>
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => save(true, true)} className="flex-1 min-w-[140px] bg-[#FF4D00] text-white font-black uppercase text-xs py-3 px-4 rounded-xl hover:bg-orange-500 transition-all">
                Tout accepter
              </button>
              <button onClick={() => setCustomizing(true)} className="flex-1 min-w-[140px] bg-slate-700 text-white font-black uppercase text-xs py-3 px-4 rounded-xl hover:bg-slate-600 transition-all">
                Personnaliser
              </button>
              <button onClick={() => save(false, false)} className="flex-1 min-w-[140px] bg-slate-800 text-slate-400 font-black uppercase text-xs py-3 px-4 rounded-xl border border-white/10 hover:border-white/20 transition-all">
                Tout refuser
              </button>
            </div>
          </>
        ) : (
          <>
            <h3 className="font-black text-white uppercase tracking-tight text-base mb-4">Personnaliser mes préférences</h3>
            <div className="space-y-3 mb-5">
              {[
                { key: 'necessary', label: 'Nécessaires', desc: 'Essentiels au fonctionnement — toujours actifs', always: true },
                { key: 'analytics', label: 'Analytiques', desc: 'Mesure d\'audience anonymisée pour améliorer le service', always: false },
                { key: 'marketing', label: 'Marketing', desc: 'Personnalisation et publicités ciblées', always: false },
              ].map(({ key, label, desc, always }) => (
                <div key={key} className="flex items-center justify-between bg-slate-800/50 rounded-2xl p-4 border border-white/10">
                  <div>
                    <p className="font-bold text-white text-sm">{label}</p>
                    <p className="text-slate-400 text-xs mt-0.5">{desc}</p>
                  </div>
                  {always ? (
                    <span className="text-emerald-400 text-xs font-black uppercase">Toujours actif</span>
                  ) : (
                    <button
                      onClick={() => setPrefs(p => ({ ...p, [key]: !p[key as 'analytics' | 'marketing'] }))}
                      className={`relative w-12 h-6 rounded-full transition-colors ${prefs[key as 'analytics' | 'marketing'] ? 'bg-[#FF4D00]' : 'bg-slate-600'}`}
                    >
                      <span className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${prefs[key as 'analytics' | 'marketing'] ? 'translate-x-7' : 'translate-x-1'}`} />
                    </button>
                  )}
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              <button onClick={() => save(prefs.analytics, prefs.marketing)} className="flex-1 bg-[#FF4D00] text-white font-black uppercase text-xs py-3 px-4 rounded-xl hover:bg-orange-500 transition-all">
                Enregistrer mes choix
              </button>
              <button onClick={() => setCustomizing(false)} className="bg-slate-700 text-white font-black uppercase text-xs py-3 px-4 rounded-xl hover:bg-slate-600 transition-all">
                Retour
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────
// FOOTER LÉGAL
// ─────────────────────────────────────────────────────────────
export const LegalFooter: React.FC<{
  onNavigate: (page: 'cgv' | 'cgu' | 'mentions' | 'confidentialite' | 'contrat-b2b') => void;
}> = ({ onNavigate }) => (
  <footer className="border-t border-white/10 bg-[#0D1220] px-6 py-8 mt-auto">
    <div className="max-w-6xl mx-auto">
      <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs font-bold uppercase tracking-widest text-slate-500 mb-4">
        {[
          { label: 'CGV', page: 'cgv' as const },
          { label: 'CGU', page: 'cgu' as const },
          { label: 'Mentions légales', page: 'mentions' as const },
          { label: 'Politique de confidentialité', page: 'confidentialite' as const },
        ].map(({ label, page }) => (
          <button key={page} onClick={() => onNavigate(page)} className="hover:text-[#FF4D00] transition-colors">
            {label}
          </button>
        ))}
      </div>
      <p className="text-center text-slate-600 text-xs">
        © {new Date().getFullYear()} {C.name} — Groupe {C.group}. Tous droits réservés.
      </p>
    </div>
  </footer>
);

// ─────────────────────────────────────────────────────────────
// MODALE CONTRAT B2B (onboarding entreprise)
// ─────────────────────────────────────────────────────────────
export const ContratB2BModal: React.FC<{
  onAccept: () => void;
  onDecline: () => void;
}> = ({ onAccept, onDecline }) => {
  const [hasScrolled, setHasScrolled] = useState(false);
  const [accepted, setAccepted] = useState(false);

  return (
    <div className="fixed inset-0 z-[9998] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#0D1220] border border-white/20 rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header modale */}
        <div className="p-6 border-b border-white/10 shrink-0">
          <h2 className="font-black italic uppercase tracking-tighter text-xl text-white">Contrat B2B TalentBook</h2>
          <p className="text-slate-400 text-xs uppercase font-bold mt-1">Lisez le contrat en entier pour pouvoir l'accepter</p>
        </div>

        {/* Corps scrollable */}
        <div
          className="flex-1 overflow-y-auto p-6 space-y-4 text-sm text-slate-300 leading-relaxed"
          onScroll={e => {
            const el = e.currentTarget;
            if (el.scrollHeight - el.scrollTop <= el.clientHeight + 50) setHasScrolled(true);
          }}
        >
          {[
            ['1', 'Objet', 'Le présent contrat définit les conditions d\'accès et d\'utilisation des services TalentBook pour la mise en relation avec des candidats du secteur GMS.'],
            ['2', 'Durée', 'Contrat de 12 mois renouvelable tacitement, résiliable avec 30 jours de préavis.'],
            ['3', 'Obligations TalentBook', 'Disponibilité 99,5%, qualification Mini-SCOPE, conformité RGPD, support 48h ouvrées.'],
            ['4', 'Obligations Client', 'Utilisation conforme, confidentialité candidates, non-cession d\'accès, paiement dans les délais.'],
            ['5', 'Tarification', 'Selon grille tarifaire en vigueur. Facturation mensuelle, paiement à 30 jours.'],
            ['6', 'Crédits', 'Un crédit par mise en relation. Validité 12 mois. Restitution si profil indisponible.'],
            ['7', 'Confidentialité', 'Obligation réciproque de confidentialité, survivant 3 ans à la résiliation.'],
            ['8', 'RGPD / DPA', 'TalentBook agit comme sous-traitant. Conditions détaillées en annexe DPA.'],
            ['9', 'Propriété intellectuelle', 'Licence d\'usage non exclusive. Tous droits conservés par TalentBook.'],
            ['10', 'Résiliation', 'Résiliation possible en cas de manquement grave non corrigé sous 15 jours.'],
            ['11', 'Responsabilité', `Limitée aux sommes versées sur 12 mois. TalentBook non responsable des décisions RH.`],
            ['12', 'Droit applicable', `Droit français. Tribunal de Commerce de ${legalField(C.court_city, '[ville à compléter]')}.`],
          ].map(([n, title, content]) => (
            <div key={n} className="border-l-2 border-[#FF4D00]/30 pl-4">
              <p className="font-black text-white text-xs uppercase tracking-widest mb-1">Art. {n} — {title}</p>
              <p>{content}</p>
            </div>
          ))}
          {/* Sentinel scroll */}
          <div className="h-4" />
        </div>

        {/* Footer modale */}
        <div className="p-6 border-t border-white/10 space-y-4 shrink-0">
          {!hasScrolled && (
            <p className="text-center text-yellow-400 text-xs font-bold uppercase animate-pulse">
              ↓ Faites défiler jusqu'en bas pour activer l'acceptation
            </p>
          )}
          <label className={`flex items-start gap-3 cursor-pointer ${!hasScrolled ? 'opacity-30 pointer-events-none' : ''}`}>
            <input type="checkbox" checked={accepted} onChange={e => setAccepted(e.target.checked)} className="mt-0.5 w-4 h-4 accent-orange-500" />
            <span className="text-xs text-slate-300">
              J'ai lu et j'accepte l'intégralité du contrat B2B TalentBook (version 1.0) au nom de mon entreprise.
            </span>
          </label>
          <div className="flex gap-3">
            <button
              onClick={() => hasScrolled && accepted && onAccept()}
              disabled={!hasScrolled || !accepted}
              className="flex-1 bg-[#FF4D00] text-white font-black uppercase text-sm py-4 rounded-2xl disabled:opacity-30 disabled:cursor-not-allowed hover:bg-orange-500 transition-all"
            >
              J'accepte le contrat ✓
            </button>
            <button onClick={onDecline} className="bg-slate-700 text-slate-300 font-black uppercase text-sm py-4 px-6 rounded-2xl hover:bg-slate-600 transition-all">
              Refuser
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
